document.addEventListener("DOMContentLoaded", () => {
  // ===== ELEMENTOS =====
  const chk = document.getElementById("checkbox");
  const nomeCompleto = document.getElementById("nomeCompleto");
  const profileImage = document.getElementById("profileImage");
  const uploadInput = document.getElementById("uploadInput");

  const inputNome = document.getElementById("nomeCompleto"); // para mostrar na aba Perfil
  const textareaSobre = document.querySelector("#perfil textarea");

  // ===== MODO ESCURO =====
  if (localStorage.getItem("modo") === "dark") {
    document.body.classList.add("dark");
    chk.checked = true;
  }

  chk.addEventListener("change", () => {
    document.body.classList.toggle("dark");
    localStorage.setItem(
      "modo",
      document.body.classList.contains("dark") ? "dark" : "light"
    );
  });

  // ===== CARREGAR DADOS DO USUÁRIO =====
  const user = JSON.parse(localStorage.getItem("usuario"));
  if (user) {
    nomeCompleto.textContent = user.nome_usuario || "Seu Nome";

    if (user.avatar_url) {
      profileImage.src = "http://localhost:3001" + user.avatar_url;
    }

    if (user.sobre_mim) {
      textareaSobre.value = user.sobre_mim;
    }
  }

  // ===== UPLOAD DE FOTO =====
  uploadInput.addEventListener("change", async () => {
    if (uploadInput.files.length > 0) {
      const file = uploadInput.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        profileImage.src = e.target.result;
        if (user) {
          user.avatar_url = e.target.result;
          localStorage.setItem("usuario", JSON.stringify(user));
        }
      };
      reader.readAsDataURL(file);
    }
  });

  // ===== MODAL DE FOTO =====
  const modal = document.getElementById("modal");
  const modalImage = document.getElementById("modalImage");

  profileImage.addEventListener("click", () => {
    modalImage.src = profileImage.src;
    modal.style.display = "flex";
  });

  modal.addEventListener("click", () => {
    modal.style.display = "none";
  });

  // ===== TABS =====
  const tabButtons = document.querySelectorAll(".tab-btn");
  const tabContents = document.querySelectorAll(".tab-content");

  tabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      tabButtons.forEach(b => b.classList.remove("active"));
      tabContents.forEach(c => c.classList.remove("active"));
      btn.classList.add("active");
      const tab = btn.dataset.tab;
      document.getElementById(tab).classList.add("active");
    });
  });

  // ===== TOGGLE BOTÕES =====
  document.querySelectorAll(".toggle-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const ativo = btn.classList.toggle("ativo");
      btn.classList.toggle("desativado", !ativo);
      btn.textContent = ativo ? "Ativado" : "Desativado";
    });
  });

  // ===== SALVAR SOBRE MIM =====
  textareaSobre.addEventListener("blur", () => {
    if (user) {
      user.sobre_mim = textareaSobre.value;
      localStorage.setItem("usuario", JSON.stringify(user));
    }
  });

  // ===== EXCLUIR CONTA =====
  window.excluirConta = () => {
    if (confirm("⚠️ Tem certeza que deseja excluir sua conta permanentemente?")) {
      localStorage.removeItem("usuario");
      alert("Conta excluída com sucesso (exemplo).");
      window.location.href = "index.html";
    }
  };
});
