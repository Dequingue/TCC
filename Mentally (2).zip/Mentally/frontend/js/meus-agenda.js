// localStorage Usuario
document.addEventListener("DOMContentLoaded", () => {
    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (usuario && usuario.nome) {
        document.getElementById("nome-usuario").textContent = usuario.nome;
    }
});

const btnMobile = document.getElementById('btn-mobile');
const nav = document.getElementById('nav');
const menu = document.getElementById('menu');
const desktopSocial = document.getElementById('navigation_social');
const desktopIcons = document.getElementById('icons');
const desktopTitle = document.getElementById('title');
const hamburger = document.getElementById('hamburger');

btnMobile.addEventListener('click', toggleMenu);
btnMobile.addEventListener('touchstart', toggleMenu);

function toggleMenu(event) {
  if (event.type === 'touchstart') event.preventDefault();

  nav.classList.toggle('active');
  hamburger.classList.toggle('active');

  const active = nav.classList.contains('active');
  event.currentTarget.setAttribute('aria-expanded', active);
  event.currentTarget.setAttribute('aria-label', active ? 'Fechar Menu' : 'Abrir Menu');

  // Quando abrir o menu mobile
  if (active && window.innerWidth <= 1100) {
    // Adiciona o título
    if (!document.getElementById('mobile-title')) {
      const mobileTitle = desktopTitle.cloneNode(true);
      mobileTitle.id = 'mobile-title';
      menu.prepend(mobileTitle);
    }

    
    // Adiciona os ícones sociais
    if (!document.getElementById('mobile-social')) {
      const mobileSocial = desktopSocial.cloneNode(true);
      mobileSocial.id = 'mobile-social';
      menu.appendChild(mobileSocial);
    }
    
    // Adiciona os ícones
    if (!document.getElementById('mobile-icons')) {
      const mobileIcons = desktopIcons.cloneNode(true);
      mobileIcons.id = 'mobile-icons';
      menu.appendChild(mobileIcons);
    }
  }

  // Quando fechar o menu mobile
  if (!active) {
    const mobileTitle = document.getElementById('mobile-title');
    const mobileSocial = document.getElementById('mobile-social');
    const mobileIcons = document.getElementById('mobile-icons');

    if (mobileTitle) mobileTitle.remove();
    if (mobileSocial) mobileSocial.remove();
    if (mobileIcons) mobileIcons.remove();
  }
}



//modo escuro- modo claro
const chk = document.getElementById('checkbox');
const logo = document.getElementById('logo'); // agora pega o <img>

// Verifica se já tem preferência salva e aplica
if(localStorage.getItem('modo') === 'dark'){
  document.body.classList.add('dark');
  chk.checked = true;
  logo.src = "/img/mentaally colorido.png"; // versão clara
} else {
  logo.src = "/img/mentaally.png"; // versão escuraa
}

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark');
  
  if(document.body.classList.contains('dark')){
    localStorage.setItem('modo', 'dark');
    logo.src = "/img/mentaally colorido.png"; // troca p/ dark

  } else {
    localStorage.setItem('modo', 'light');
    logo.src = "/img/mentaally.png"; // volta p/ light
  
  }
});

function showTab(tab) {
      document.querySelectorAll('.tab-content').forEach(el => el.style.display = "none");
      document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove("active"));
      document.getElementById(tab).style.display = "block";
      event.target.classList.add("active");
    }