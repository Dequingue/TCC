const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const path = require("path");
const multer = require("multer");

const app = express();
app.use(cors());
app.use(express.json());

// SERVIR FRONTEND
const frontendPath = path.join(__dirname, "../frontend");
app.use(express.static(frontendPath));

// SERVIR ARQUIVOS DE IMAGEM (uploads)
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// CONFIGURAÇÃO DO MULTER (UPLOAD DE AVATAR)
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + ext);
  }
});
const upload = multer({ storage });

// CONEXÃO COM MYSQL
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "MENTALLY"
});

db.connect(err => {
  if (err) return console.error("❌ Erro ao conectar MySQL:", err);
  console.log("✅ Conectado ao MySQL");
});

// ======================= ROTAS ============================

// 🔍 Obter todos usuários
app.get("/usuarios", (req, res) => {
  db.query(
    "SELECT id_usuario, CPF, nome_usuario, email_usuario, telefone, plano_tratamento, criado_em, avatar FROM USUARIO",
    (err, results) => {
      if (err) return res.status(500).json(err);
      res.json(results);
    }
  );
});

// ✅ Cadastro de novo usuário
app.post("/usuarios", (req, res) => {
  const { nome_usuario, email_usuario, senha_usuario } = req.body;
  if (!nome_usuario || !email_usuario || !senha_usuario)
    return res.status(400).json({ message: "Preencha todos os campos." });

  const sql = "INSERT INTO USUARIO (nome_usuario, email_usuario, senha_usuario) VALUES (?, ?, SHA2(?,256))";
  db.query(sql, [nome_usuario, email_usuario, senha_usuario], (err) => {
    if (err) return res.status(500).json({ message: "Erro ao cadastrar usuário." });
    res.json({ message: "Usuário cadastrado com sucesso!" });
  });
});

// 🔐 Login
app.post("/login", (req, res) => {
  const { email_usuario, senha_usuario } = req.body;
  if (!email_usuario || !senha_usuario)
    return res.status(400).json({ message: "Preencha e-mail e senha." });

  const sql = "SELECT * FROM USUARIO WHERE email_usuario = ? AND senha_usuario = SHA2(?,256)";
  db.query(sql, [email_usuario, senha_usuario], (err, results) => {
    if (err) return res.status(500).json({ message: "Erro interno no servidor." });
    if (results.length === 0) return res.status(401).json({ message: "E-mail ou senha inválidos." });
    res.json({ message: "Login realizado com sucesso!", usuario: results[0] });
  });
});

// ✏️ Atualizar perfil
app.put('/usuarios/:id_usuario', (req, res) => {
  const { id_usuario } = req.params;
  const { nome_usuario, email_usuario, telefone, cpf } = req.body;

  const sql = "UPDATE USUARIO SET nome_usuario = ?, email_usuario = ?, telefone = ?, CPF = ? WHERE id_usuario = ?";
  db.query(sql, [nome_usuario, email_usuario, telefone, cpf, id_usuario], (err, result) => {
    if (err) {
      console.error('Erro ao atualizar perfil:', err);
      return res.status(500).json({ error: "Erro ao atualizar perfil" });
    }
    res.json({ message: "Perfil atualizado com sucesso!" });
  });
});


// 🖼️ Upload de avatar
app.post("/usuarios/avatar", upload.single("avatar"), (req, res) => {
  const { id_usuario } = req.body;

  if (!req.file || !id_usuario) {
    return res.status(400).json({ message: "Arquivo ou ID do usuário ausente." });
  }

  const avatarUrl = `http://localhost:3001/uploads/${req.file.filename}`;
  const sql = "UPDATE USUARIO SET avatar = ? WHERE id_usuario = ?";

  db.query(sql, [avatarUrl, id_usuario], (err, result) => {
    if (err) {
      console.error("Erro ao salvar avatar:", err);
      return res.status(500).json({ message: "Erro ao salvar avatar." });
    }
    res.json({ message: "Avatar atualizado com sucesso!", url: avatarUrl });
  });
});

// 📅 Agendamento
app.post("/agendamentos", (req, res) => {
  console.log("📥 Dados recebidos para agendamento:", req.body);
  const {
    PROFISSIONAIS_idProfissional,
    USUARIO_CPF,
    data_consulta,
    hora_consulta,
    relato_consulta = null,
    nota_consulta = null,
    observacao_consulta = null
  } = req.body;

  const sql = `
    INSERT INTO CONSULTA (
      PROFISSIONAIS_idProfissional,
      USUARIO_CPF,
      data_consulta,
      hora_consulta,
      relato_consulta,
      nota_consulta,
      observacao_consulta
    ) VALUES (?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(sql, [
    PROFISSIONAIS_idProfissional,
    USUARIO_CPF,
    data_consulta,
    hora_consulta,
    relato_consulta,
    nota_consulta,
    observacao_consulta
  ], (err, result) => {
    if (err) {
      console.error("Erro ao agendar:", err);
      return res.status(500).json({ message: "Erro ao agendar." });
    }
    res.json({ message: "Agendamento realizado com sucesso!" });
  });
});

// SPA fallback
app.get("/", (req, res) => {
  res.sendFile(path.join(frontendPath, "index.html"));
});

// Iniciar servidor
const PORT = 3001;
app.listen(PORT, () => console.log(`🚀 Servidor rodando em http://localhost:${PORT}`));
