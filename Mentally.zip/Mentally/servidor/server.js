const express = require("express");
const app = express();
const port = 3001;
const mysql = require("mysql2");
const cors = require("cors");
const bcrypt = require("bcrypt");
const multer = require("multer");
const path = require("path");


app.use(cors());
app.use(express.json());
app.use(express.static("frontend"));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Configuração do multer para upload de arquivos
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage: storage });

// Conexão com o banco de dados
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "mentally",
});

db.connect((err) => {
  if (err) {
    console.error("Erro ao conectar ao banco de dados:", err);
    return;
  }
  console.log("Conectado ao banco de dados MySQL");
});


// ROTA PRINCIPAL

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "frontend", "index.html"));
});

// ==================== USUÁRIOS ====================

// Criar usuário
app.post("/usuarios", async (req, res) => {
  const { nome_usuario, email_usuario, senha_usuario } = req.body;
  if (!nome_usuario || !email_usuario || !senha_usuario)
    return res.status(400).json({ message: "Preencha todos os campos." });

  try {
    const hashedPassword = await bcrypt.hash(senha_usuario, 10);
    const sql = "INSERT INTO USUARIO (nome_usuario, email_usuario, senha_usuario) VALUES (?, ?, ?)";

    db.query(sql, [nome_usuario, email_usuario, hashedPassword], (err) => {
      if (err) return res.status(500).json({ message: "Erro ao cadastrar usuário." });
      res.json({ message: "Usuário cadastrado com sucesso!" });
    });
  } catch (err) {
    console.error("Erro ao registrar usuário:", err);
    res.status(500).json({ message: "Erro interno." });
  }
});

// Listar todos os usuários
app.get("/usuarios", (req, res) => {
  const sql = "SELECT * FROM USUARIO";
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ message: "Erro ao buscar usuários." });
    res.json(results);
  });
});

// Buscar um usuário por ID
app.get("/usuarios/:id_usuario", (req, res) => {
  const { id_usuario } = req.params;
  const sql = "SELECT * FROM USUARIO WHERE id_usuario = ?";
  db.query(sql, [id_usuario], (err, results) => {
    if (err) return res.status(500).json({ message: "Erro ao buscar usuário." });
    if (results.length === 0) return res.status(404).json({ message: "Usuário não encontrado." });
    res.json(results[0]);
  });
});

// Atualizar um usuário
app.put("/usuarios/:id_usuario", (req, res) => {
  const { id_usuario } = req.params;
  const { nome_usuario, email_usuario, telefone } = req.body;
  const sql = "UPDATE USUARIO SET nome_usuario = ?, email_usuario = ?, telefone = ? WHERE id_usuario = ?";
  db.query(sql, [nome_usuario, email_usuario, telefone, id_usuario], (err, result) => {
    if (err) return res.status(500).json({ message: "Erro ao atualizar usuário." });
    res.json({ message: "Usuário atualizado com sucesso!" });
  });
});

// Upload de avatar
app.post("/usuarios/:id_usuario/avatar", upload.single("avatar"), (req, res) => {
  const { id_usuario } = req.params;
  const avatar = req.file.filename;
  const sql = "UPDATE USUARIO SET avatar = ? WHERE id_usuario = ?";
  db.query(sql, [avatar, id_usuario], (err) => {
    if (err) return res.status(500).json({ message: "Erro ao enviar avatar." });
    res.json({ message: "Avatar enviado com sucesso!", avatar });
  });
});

// Excluir usuário
app.delete("/usuarios/:id_usuario", (req, res) => {
  const { id_usuario } = req.params;
  const sql = "DELETE FROM USUARIO WHERE id_usuario = ?";
  db.query(sql, [id_usuario], (err, result) => {
    if (err) return res.status(500).json({ message: "Erro ao excluir usuário." });
    if (result.affectedRows === 0) return res.status(404).json({ message: "Usuário não encontrado." });
    res.json({ message: "Conta excluída com sucesso!" });
  });
});


// ==================== AUTENTICAÇÃO ====================

// Login de usuário
app.post("/login", (req, res) => {
  const { email, senha } = req.body;
  console.log("Login requisitado:", { email, senha });

  if (!email || !senha) {
    return res.status(400).json({ message: "Preencha e-mail e senha." });
  }

  const verificarSenha = (user, tipo) => {
    const senhaHash = tipo === "usuario" ? user.senha_usuario : user.senha_profissional;
    bcrypt.compare(senha, senhaHash, (err, resultado) => {
      if (err) {
        console.error("Erro ao comparar senha:", err);
        return res.status(500).json({ message: "Erro no servidor." });
      }
      if (!resultado) {
        console.log("Senha incorreta para", tipo, user.email_usuario || user.email_profissional);
        return res.status(401).json({ message: "E-mail ou senha inválidos." });
      }

      console.log("Login bem-sucedido:", tipo, user.email_usuario || user.email_profissional);
      return res.json({
        message: "Login realizado com sucesso!",
        tipoConta: tipo,
        usuario: user
      });
    });
  };

  // verifica usuário
  db.query("SELECT * FROM USUARIO WHERE email_usuario = ?", [email], (err, resultsUsuario) => {
    if (err) {
      console.error("Erro ao buscar usuario:", err);
      return res.status(500).json({ message: "Erro no banco de dados." });
    }

    if (resultsUsuario.length > 0) {
      return verificarSenha(resultsUsuario[0], "usuario");
    }

    // senão, verifica profissional
    db.query("SELECT * FROM PROFISSIONAIS WHERE email_profissional = ?", [email], (err, resultsProfissional) => {
      if (err) {
        console.error("Erro ao buscar profissional:", err);
        return res.status(500).json({ message: "Erro no banco de dados." });
      }

      if (resultsProfissional.length > 0) {
        return verificarSenha(resultsProfissional[0], "profissional");
      }

      console.log("Nenhum usuario ou profissional encontrado para email:", email);
      return res.status(401).json({ message: "E-mail ou senha inválidos." });
    });
  });
});


// ==================== PROFISSIONAIS ====================

// Converte o db.query para uma função que retorna Promise
function queryAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.query(sql, params, (err, results) => {
      if (err) reject(err);
      else resolve(results);
    });
  });
}

// Cadastrar profissional
app.post("/profissionais", async (req, res) => {
  const {
    nome_profissional,
    email_profissional,
    senha_profissional,
    registro_profissional,
    especialidade,
    areaAtuacao
  } = req.body;

  if (!nome_profissional || !email_profissional || !senha_profissional || !registro_profissional || !especialidade || !areaAtuacao) {
    return res.status(400).json({ message: "Preencha todos os campos obrigatórios." });
  }

  try {
    const hashedPassword = await bcrypt.hash(senha_profissional, 10);

    // 1. Verifica se a especialidade existe ou insere
    let especialidadeId;
    let results = await queryAsync("SELECT especialidade_PK FROM ESPECIALIDADE WHERE especialidade = ?", [especialidade]);
    if (results.length > 0) {
      especialidadeId = results[0].especialidade_PK;
    } else {
      results = await queryAsync("INSERT INTO ESPECIALIDADE (especialidade) VALUES (?)", [especialidade]);
      especialidadeId = results.insertId;
    }

    // 2. Verifica se a área de atuação existe ou insere
    let areaId;
    results = await queryAsync("SELECT areaAtuacao_PK FROM AREA_ATUACAO WHERE areaAtuacao = ?", [areaAtuacao]);
    if (results.length > 0) {
      areaId = results[0].areaAtuacao_PK;
    } else {
      results = await queryAsync("INSERT INTO AREA_ATUACAO (areaAtuacao) VALUES (?)", [areaAtuacao]);
      areaId = results.insertId;
    }

    // 3. Insere o profissional
    await queryAsync(
      `INSERT INTO PROFISSIONAIS 
      (nome_profissional, email_profissional, senha_profissional, registro_profissional, ESPECIALIDADE_especialidade_PK, AREA_ATUACAO_areaAtuacao_PK)
      VALUES (?, ?, ?, ?, ?, ?)`,
      [nome_profissional, email_profissional, hashedPassword, registro_profissional, especialidadeId, areaId]
    );

    return res.json({ message: "Profissional cadastrado com sucesso!" });

  } catch (error) {
    console.error("Erro ao cadastrar profissional:", error);
    return res.status(500).json({ message: "Erro interno no servidor." });
  }
});



// Listar profissionais com especialidade e área de atuação (usando VIEW)
app.get('/profissionais/especialidades', (req, res) => {
  const sql = 'SELECT * FROM prof_especialidades';
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ message: "Erro ao buscar dados." });
    res.json(results);
  });
});


// ==================== APOIO ====================

// Listar especialidades
app.get("/especialidades", (req, res) => {
  const sql = "SELECT especialidade_PK, especialidade FROM ESPECIALIDADE ORDER BY especialidade";
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ message: "Erro ao buscar especialidades." });
    res.json(results);
  });
});

// Listar áreas de atuação
app.get("/areas", (req, res) => {
  const sql = "SELECT areaAtuacao_PK, areaAtuacao FROM AREA_ATUACAO ORDER BY areaAtuacao";
  db.query(sql, (err, results) => {
    if (err) return res.status(500).json({ message: "Erro ao buscar áreas de atuação." });
    res.json(results);
  });
});


// ==================== SERVIDOR ====================
app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
