const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const path = require("path");
const multer = require("multer");

const app = express();
app.use(cors());
app.use(express.json());

// SERVIR FRONTEND
const frontendPath = path.join(__dirname, "../frontend");
app.use(express.static(frontendPath));

// SERVIR ARQUIVOS DE IMAGEM (uploads)
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// CONFIGURAÇÃO DO MULTER (UPLOAD DE AVATAR)
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + ext);
  }
});
const upload = multer({ storage });

// CONEXÃO COM MYSQL
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "MENTALLY"
});

db.connect(err => {
  if (err) return console.error("❌ Erro ao conectar MySQL:", err);
  console.log("✅ Conectado ao MySQL");
});

// ======================= ROTAS ============================

// 🔍 Obter todos usuários
app.get("/usuarios", (req, res) => {
  db.query(
    "SELECT id_usuario, CPF, nome_usuario, email_usuario, telefone, plano_tratamento, criado_em, avatar FROM USUARIO",
    (err, results) => {
      if (err) return res.status(500).json(err);
      res.json(results);
    }
  );
});

// ✅ Cadastro de novo usuário
app.post("/usuarios", (req, res) => {
  const { nome_usuario, email_usuario, senha_usuario } = req.body;
  if (!nome_usuario || !email_usuario || !senha_usuario)
    return res.status(400).json({ message: "Preencha todos os campos." });

  const sql = "INSERT INTO USUARIO (nome_usuario, email_usuario, senha_usuario) VALUES (?, ?, SHA2(?,256))";
  db.query(sql, [nome_usuario, email_usuario, senha_usuario], (err) => {
    if (err) return res.status(500).json({ message: "Erro ao cadastrar usuário." });
    res.json({ message: "Usuário cadastrado com sucesso!" });
  });
});

// ✅ cadastro de novo profissional
app.post("/profissionais", async (req, res) => {
  const {
    nome_profissional,
    email_profissional,
    senha_profissional,
    registro_profissional,
    especialidade,
    areaAtuacao
  } = req.body;

  try {
    // 1. Garantir que Especialidade existe
    let [espRows] = await db
      .promise()
      .query("SELECT especialidade_PK FROM ESPECIALIDADE WHERE especialidade = ?", [especialidade]);

    let especialidadeId;
    if (espRows.length > 0) {
      especialidadeId = espRows[0].especialidade_PK;
    } else {
      let [insertEsp] = await db
        .promise()
        .query("INSERT INTO ESPECIALIDADE (especialidade) VALUES (?)", [especialidade]);
      especialidadeId = insertEsp.insertId;
    }

    // 2. Garantir que Área de Atuação existe
    let [areaRows] = await db
      .promise()
      .query("SELECT areaAtuacao_PK FROM AREA_ATUACAO WHERE areaAtuacao = ?", [areaAtuacao]);

    let areaId;
    if (areaRows.length > 0) {
      areaId = areaRows[0].areaAtuacao_PK;
    } else {
      let [insertArea] = await db
        .promise()
        .query("INSERT INTO AREA_ATUACAO (areaAtuacao) VALUES (?)", [areaAtuacao]);
      areaId = insertArea.insertId;
    }

    // 3. Inserir Profissional com os IDs corretos e senha criptografada
    await db
      .promise()
      .query(
        `INSERT INTO PROFISSIONAIS 
        (AREA_ATUACAO_areaAtuacao_PK, ESPECIALIDADE_especialidade_PK, nome_profissional, senha_profissional, email_profissional, registro_profissional) 
        VALUES (?, ?, ?, SHA2(?,256), ?, ?)`,
        [areaId, especialidadeId, nome_profissional, senha_profissional, email_profissional, registro_profissional]
      );

    res.json({ message: "Profissional cadastrado com sucesso!" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao cadastrar profissional" });
  }
});




// 🔐 Login (usuário ou profissional)
app.post("/login", (req, res) => {
  const { email, senha } = req.body;

  if (!email || !senha) {
    return res.status(400).json({ success: false, message: "Preencha e-mail e senha." });
  }

  // 1️⃣ Tenta login como USUÁRIO
  const sqlUsuario = "SELECT * FROM USUARIO WHERE email_usuario = ? AND senha_usuario = SHA2(?,256)";
  db.query(sqlUsuario, [email, senha], (err, results) => {
    if (err) {
      console.error("Erro login usuário:", err);
      return res.status(500).json({ success: false, message: "Erro interno no servidor." });
    }

    if (results.length > 0) {
      return res.json({
        success: true,
        tipo: "usuario",
        usuario: results[0]
      });
    }

    // 2️⃣ Se não achou, tenta login como PROFISSIONAL
    const sqlProfissional = "SELECT * FROM PROFISSIONAIS WHERE email_profissional = ? AND senha_profissional = SHA2(?,256)";
    db.query(sqlProfissional, [email, senha], (err2, results2) => {
      if (err2) {
        console.error("Erro login profissional:", err2);
        return res.status(500).json({ success: false, message: "Erro interno no servidor." });
      }

      if (results2.length > 0) {
        return res.json({
          success: true,
          tipo: "profissional",
          profissional: results2[0]
        });
      }

      // 3️⃣ Nenhum encontrado
      return res.status(401).json({ success: false, message: "E-mail ou senha inválidos." });
    });
  });
});



// ✏️ Atualizar perfil
app.put('/usuarios/:id_usuario', (req, res) => {
  const { id_usuario } = req.params;
  const { nome_usuario, email_usuario, telefone, cpf, dtNascimento, plano_tratamento } = req.body;

  const sql = "UPDATE USUARIO SET nome_usuario = ?, email_usuario = ?, telefone = ?, CPF = ?, dtNascimento = ?, plano_tratamento = ? WHERE id_usuario = ?";
  db.query(sql, [nome_usuario, email_usuario, telefone, cpf, dtNascimento, plano_tratamento, id_usuario], (err, result) => {
    if (err) {
      console.error('Erro ao atualizar perfil:', err);
      return res.status(500).json({ error: "Erro ao atualizar perfil" });
    }
    res.json({ message: "Perfil atualizado com sucesso!" });
  });
});

app.get('/usuarios/:id_usuario', (req, res) => {
  const { id_usuario } = req.params;

  const sql = `
  SELECT 
    id_usuario, 
    CPF AS cpf, 
    nome_usuario, 
    email_usuario, 
    telefone, 
    DATE_FORMAT(dtNascimento, '%Y-%m-%d') AS dtNascimento, 
    plano_tratamento, 
    criado_em AS data_criacao, 
    avatar AS avatar_url 
    FROM USUARIO 
    WHERE id_usuario = ?`;

  db.query(sql, [id_usuario], (err, results) => {
    if (err) {
      console.error('Erro ao buscar usuário:', err);
      return res.status(500).json({ error: 'Erro ao buscar usuário' });
    }

    if (results.length === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    res.json(results[0]);
  });
});



// 🖼️ Upload de avatar
app.post("/usuarios/avatar", upload.single("avatar"), (req, res) => {
  const { id_usuario } = req.body;

  if (!req.file || !id_usuario) {
    return res.status(400).json({ message: "Arquivo ou ID do usuário ausente." });
  }

  const avatarUrl = `http://localhost:3001/uploads/${req.file.filename}`;
  const sql = "UPDATE USUARIO SET avatar = ? WHERE id_usuario = ?";

  db.query(sql, [avatarUrl, id_usuario], (err, result) => {
    if (err) {
      console.error("Erro ao salvar avatar:", err);
      return res.status(500).json({ message: "Erro ao salvar avatar." });
    }
    res.json({ message: "Avatar atualizado com sucesso!", url: avatarUrl });
  });
});

// 📅 Agendamento
app.post("/agendamentos", (req, res) => {
  console.log("📥 Dados recebidos para agendamento:", req.body);
  const {
    PROFISSIONAIS_idProfissional,
    USUARIO_idUsuario, // ✅ agora igual à tabela
    data_consulta,
    hora_consulta,
    relato_consulta,
    nota_consulta,
    observacao_consulta
  } = req.body;

  if (!PROFISSIONAIS_idProfissional || !USUARIO_idUsuario || !data_consulta || !hora_consulta) {
    return res.status(400).json({ message: 'Campos obrigatórios ausentes.' });
  }

  const sql = `
    INSERT INTO CONSULTA (
      PROFISSIONAIS_idProfissional,
      USUARIO_idUsuario,
      data_consulta,
      hora_consulta,
      relato_consulta,
      nota_consulta,
      observacao_consulta
    ) VALUES (?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(sql, [
    PROFISSIONAIS_idProfissional,
    USUARIO_idUsuario, // ✅ corrigido
    data_consulta,
    hora_consulta,
    relato_consulta,
    nota_consulta,
    observacao_consulta
  ], (err, result) => {
    if (err) {
      console.error("Erro ao agendar:", err);
      return res.status(500).json({ message: "Erro ao agendar." });
    }
    res.json({ message: "Agendamento realizado com sucesso!" });
  });
});


// 🔍 Listar todos os profissionais
app.get("/profissionais", (req, res) => {
  const sql = `
    SELECT 
      p.idProfissional,
      p.nome_profissional,
      p.email_profissional,
      p.registro_profissional,
      e.especialidade,
      a.areaAtuacao
    FROM PROFISSIONAIS p
    JOIN ESPECIALIDADE e ON p.ESPECIALIDADE_especialidade_PK = e.especialidade_PK
    JOIN AREA_ATUACAO a ON p.AREA_ATUACAO_areaAtuacao_PK = a.areaAtuacao_PK
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Erro ao buscar profissionais:", err);
      return res.status(500).json({ error: "Erro ao buscar profissionais" });
    }
    res.json(results);
  });
});

// SPA fallback
app.get("/", (req, res) => {
  res.sendFile(path.join(frontendPath, "index.html"));
});

// Iniciar servidor
const PORT = 3001;
app.listen(PORT, () => console.log(`🚀 Servidor rodando em http://localhost:${PORT}`));


// 🗑️ Excluir usuário
app.delete("/usuarios/:id_usuario", (req, res) => {
  const { id_usuario } = req.params;

  const sql = "DELETE FROM USUARIO WHERE id_usuario = ?";

  db.query(sql, [id_usuario], (err, result) => {
    if (err) {
      console.error("Erro ao excluir usuário:", err);
      return res.status(500).json({ message: "Erro ao excluir usuário." });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Usuário não encontrado." });
    }

    res.json({ message: "Conta excluída com sucesso!" });
  });
});

