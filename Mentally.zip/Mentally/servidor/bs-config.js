// servidor/bs-config.js
module.exports = {
  proxy: "http://localhost:3001",
  files: ["../frontend/**/*.*"],   // observa todos os arquivos do frontend
  port: 3002,
  open: true,
  ui: { port: 3003 },
  injectChanges: false,            // força reload completo
  reloadDelay: 100,
  watchOptions: {                  // <<< aqui
    ignoreInitial: true,
    awaitWriteFinish: {
      stabilityThreshold: 100,
      pollInterval: 50
    }
  },
  snippetOptions: {
    rule: {
      match: /<\/body>/i,
      fn: function (snippet, match) {
        return snippet + match;
      }
    }
  }
};