document.addEventListener("DOMContentLoaded", () => {
  const agendaList = document.getElementById("agendaList");
  const addAgendamentoBtn = document.getElementById("addAgendamentoBtn");
  const modal = document.getElementById("modal");
  const modalTitle = document.getElementById("modalTitle");
  const inputPaciente = document.getElementById("inputPaciente");
  const inputData = document.getElementById("inputData");
  const inputHora = document.getElementById("inputHora");
  const saveAgendamentoBtn = document.getElementById("saveAgendamentoBtn");
  const closeModalBtn = document.getElementById("closeModal");

  let agendamentos = JSON.parse(localStorage.getItem("agendamentos")) || [];
  let editarIndex = null;

  // Função para renderizar a lista de agendamentos
  function renderAgenda() {
    agendaList.innerHTML = "";
    if (agendamentos.length === 0) {
      agendaList.innerHTML = `<p style="text-align:center; color:#ccc;">Nenhum agendamento registrado</p>`;
      return;
    }

    agendamentos.forEach((agendamento, index) => {
      const item = document.createElement("div");
      item.className = "agendamento-item";

      item.innerHTML = `
        <div class="agendamento-info">
          <span><b>Paciente:</b> ${agendamento.paciente}</span>
          <span><b>Data:</b> ${agendamento.data}</span>
          <span><b>Hora:</b> ${agendamento.hora}</span>
        </div>
        <div class="agendamento-actions">
          <button class="edit">Editar</button>
          <button class="delete">Excluir</button>
        </div>
      `;

      // Botão Editar
      item.querySelector(".edit").addEventListener("click", () => {
        abrirModal(true, index);
      });

      // Botão Excluir
      item.querySelector(".delete").addEventListener("click", () => {
        if (confirm("Deseja realmente excluir este agendamento?")) {
          agendamentos.splice(index, 1);
          salvarAgenda();
          renderAgenda();
        }
      });

      agendaList.appendChild(item);
    });
  }

  // Salvar agenda no localStorage
  function salvarAgenda() {
    localStorage.setItem("agendamentos", JSON.stringify(agendamentos));
  }

  // Abrir modal
  function abrirModal(edit = false, index = null) {
    modal.style.display = "flex";
    if (edit) {
      modalTitle.textContent = "Editar Agendamento";
      const ag = agendamentos[index];
      inputPaciente.value = ag.paciente;
      inputData.value = ag.data;
      inputHora.value = ag.hora;
      editarIndex = index;
    } else {
      modalTitle.textContent = "Novo Agendamento";
      inputPaciente.value = "";
      inputData.value = "";
      inputHora.value = "";
      editarIndex = null;
    }
  }

  // Fechar modal
  function fecharModal() {
    modal.style.display = "none";
  }

  // Salvar agendamento (novo ou editado)
  saveAgendamentoBtn.addEventListener("click", () => {
    const paciente = inputPaciente.value.trim();
    const data = inputData.value;
    const hora = inputHora.value;

    if (!paciente || !data || !hora) {
      alert("Preencha todos os campos!");
      return;
    }

    const novoAgendamento = { paciente, data, hora };

    if (editarIndex !== null) {
      agendamentos[editarIndex] = novoAgendamento;
      editarIndex = null;
    } else {
      agendamentos.push(novoAgendamento);
    }

    salvarAgenda();
    renderAgenda();
    fecharModal();
  });

  // Fechar modal
  closeModalBtn.addEventListener("click", fecharModal);
  modal.addEventListener("click", (e) => {
    if (e.target === modal) fecharModal();
  });

  // Abrir modal para novo agendamento
  addAgendamentoBtn.addEventListener("click", () => abrirModal());

  // Renderiza a agenda inicial
  renderAgenda();
});
