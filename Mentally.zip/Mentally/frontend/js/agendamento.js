// ---------- LocalStorage Usuario ----------
document.addEventListener("DOMContentLoaded", () => {
  const usuario = JSON.parse(localStorage.getItem("usuario"));
  if (usuario && usuario.nome) {
    document.getElementById("nome-usuario").textContent = usuario.nome;
  }
});

const btnMobile = document.getElementById('btn-mobile');
const nav = document.getElementById('nav');
const menu = document.getElementById('menu');
const desktopSocial = document.getElementById('navigation_social');
const desktopIcons = document.getElementById('icons');
const desktopTitle = document.getElementById('title');
const hamburger = document.getElementById('hamburger');

btnMobile.addEventListener('click', toggleMenu);
btnMobile.addEventListener('touchstart', toggleMenu);

function toggleMenu(event) {
  if (event.type === 'touchstart') event.preventDefault();

  nav.classList.toggle('active');
  hamburger.classList.toggle('active');
  
  const active = nav.classList.contains('active');
  event.currentTarget.setAttribute('aria-expanded', active);
  event.currentTarget.setAttribute('aria-label', active ? 'Fechar Menu' : 'Abrir Menu');

  // Quando abrir o menu mobile
  if (active && window.innerWidth <= 1100) {
    // Adiciona o título
    if (!document.getElementById('mobile-title')) {
      const mobileTitle = desktopTitle.cloneNode(true);
      mobileTitle.id = 'mobile-title';
      menu.prepend(mobileTitle);
    }

    
    // Adiciona os ícones sociais
    if (!document.getElementById('mobile-social')) {
      const mobileSocial = desktopSocial.cloneNode(true);
      mobileSocial.id = 'mobile-social';
      menu.appendChild(mobileSocial);
    }
    
    // Adiciona os ícones
    if (!document.getElementById('mobile-icons')) {
      const mobileIcons = desktopIcons.cloneNode(true);
      mobileIcons.id = 'mobile-icons';
      menu.appendChild(mobileIcons);
    }
  }

  // Quando fechar o menu mobile
  if (!active) {
    const mobileTitle = document.getElementById('mobile-title');
    const mobileSocial = document.getElementById('mobile-social');
    const mobileIcons = document.getElementById('mobile-icons');
    
    if (mobileTitle) mobileTitle.remove();
    if (mobileSocial) mobileSocial.remove();
    if (mobileIcons) mobileIcons.remove();
  }
}


// ---------- Dark Mode ----------
const chk = document.getElementById('checkbox');
const logo = document.getElementById('logo');

// Verifica se já tem preferência salva e aplica
if(localStorage.getItem('modo') === 'dark'){
  document.body.classList.add('dark');
  chk.checked = true;
  logo.src = "/img/mentaally colorido.png"; // versão clara
} else {
  logo.src = "/img/mentaally.png"; // versão escuraa
}

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark');
  
  if(document.body.classList.contains('dark')){
    localStorage.setItem('modo', 'dark');
    logo.src = "/img/mentaally colorido.png"; // troca p/ dark

  } else {
    localStorage.setItem('modo', 'light');
    logo.src = "/img/mentaally.png"; // volta p/ light
  
  }
});

// ---------- Steps ----------
let selectedTherapistId = null;
let selectedTherapist = null;
let selectedTag = null;
let selectedPrice = null;
let selectedDate = null;
let selectedTime = null;

function selectCard(card, therapist, tag, price) {
  selectedTherapistId = parseInt(card.dataset.id);

  document.querySelectorAll(".therapist-card").forEach(c => c.classList.remove("active"));
  card.classList.add("active");
  selectedTherapist = therapist;
  selectedTag = tag;
  selectedPrice = price;
  document.getElementById("nextBtn1").disabled = false;
}

function selectTime(btn) {
  document.querySelectorAll(".time-btn").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  selectedTime = btn.innerText;
  checkStep2();
}

function checkStep2() {
  if (selectedDate && selectedTime) {
    document.getElementById("nextBtn2").disabled = false;
  }
}

function nextStep(step) {
  document.querySelectorAll(".step-content").forEach(c => c.style.display = "none");
  document.querySelector(".step-" + step + "-content").style.display = "block";

  document.querySelectorAll(".step").forEach(s => s.classList.remove("active"));
  document.querySelector(".step-" + step).classList.add("active");

  if (step === 3) {
  const [year, month, day] = selectedDate.split('-').map(Number);
  const localDate = new Date(year, month - 1, day);

  document.getElementById("resumo").innerHTML = `
    <strong>${selectedTherapist}</strong><br>
    <span>${selectedTag}</span><br><br>
    📅 ${localDate.toLocaleDateString("pt-BR", { weekday: "long", year: "numeric", month: "long", day: "numeric" })} <br>
    ⏰ ${selectedTime}<br><br>
    <strong>Valor: ${selectedPrice}</strong>
  `;
}

}

function backStep(step) {
  nextStep(step);
}

function confirmar() {

  body: JSON.stringify({
  PROFISSIONAIS_idProfissional: profissionalId,
  USUARIO_CPF: userCPF,
  data_consulta: dataConsulta,
  hora_consulta: horaConsulta,
  relato_consulta: null,
  nota_consulta: null,
  observacao_consulta: observacao
})


  const profissionalId = selectedTherapistId; // variável global que você define ao clicar no terapeuta
  const userCPF = localStorage.getItem("cpfUsuario"); // ou outra fonte válida
  const dataConsulta = selectedDate; // selecionada no calendário
  const horaConsulta = selectedTime; // botão de horário
  const observacao = document.querySelector("textarea").value || null;

  if (!profissionalId || !userCPF || !dataConsulta || !horaConsulta) {
    alert("Por favor, preencha todas as informações obrigatórias.");
    return;
  }
  if (!userCPF) {
  alert("Seu CPF não foi informado. Complete seu perfil antes de agendar.");
  return;
  }

  fetch("http://localhost:3001/agendamentos", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      PROFISSIONAIS_idProfissional: profissionalId,
      USUARIO_CPF: userCPF,
      data_consulta: dataConsulta,
      hora_consulta: horaConsulta,
      relato_consulta: null,
      nota_consulta: null,
      observacao_consulta: observacao
    }),
  })
    .then((res) => res.json())
    .then((data) => {
      alert(data.message);
      window.location.href = "meus_agendamentos.html";
    })
    .catch((err) => {
      console.error("Erro ao agendar:", err);
      alert("Erro ao agendar. Tente novamente.");
    });
}



// ---------- Calendário ----------
const monthYear = document.getElementById("monthYear");
const calendarDays = document.getElementById("calendarDays");
const prev = document.getElementById("prev");
const next = document.getElementById("next");

let currentDate = new Date();

function renderCalendar(date) {
  const year = date.getFullYear();
  const month = date.getMonth();

  const firstDay = new Date(year, month, 1).getDay();
  const lastDay = new Date(year, month + 1, 0).getDate();
  const prevLastDay = new Date(year, month, 0).getDate();

  const months = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho",
    "Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];

  monthYear.textContent = `${months[month]} ${year}`;
  calendarDays.innerHTML = "";

  // Cabeçalho dias da semana
  const daysOfWeek = ["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"];
  daysOfWeek.forEach(d => {
    const div = document.createElement("div");
    div.textContent = d;
    div.classList.add("day-name");
    calendarDays.appendChild(div);
  });

  // Dias anteriores
  for (let i = firstDay; i > 0; i--) {
    const div = document.createElement("div");
    div.textContent = prevLastDay - i + 1;
    div.classList.add("day", "inactive");
    calendarDays.appendChild(div);
  }

  for (let i = 1; i <= lastDay; i++) {
  const div = document.createElement("div");
  div.textContent = i;
  div.classList.add("day");

  const dateOfDay = new Date(year, month, i);
  const today = new Date();
  today.setHours(0, 0, 0, 0); // Zera o tempo para comparação justa

  if (dateOfDay < today) {
    div.classList.add("inactive"); // Aplica classe visual de desativado
  } else {
    div.addEventListener("click", () => {
      document.querySelectorAll(".day").forEach(el => el.classList.remove("active"));
      div.classList.add("active");
      selectedDate = `${year}-${(month + 1).toString().padStart(2, '0')}-${i.toString().padStart(2, '0')}`;

      checkStep2();
    });

    // Marca o dia atual como ativo
    if (dateOfDay.getTime() === today.getTime()) {
      div.classList.add("active");
    }
  }

  calendarDays.appendChild(div);
}

  
}

prev.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() - 1);
  renderCalendar(currentDate);
});

next.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() + 1);
  renderCalendar(currentDate);
});

renderCalendar(currentDate);
