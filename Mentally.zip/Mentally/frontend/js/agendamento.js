// ---------- LocalStorage Usuario ----------
document.addEventListener("DOMContentLoaded", () => {
  const usuario = JSON.parse(localStorage.getItem("usuario"));
  if (usuario && usuario.nome) {
    document.getElementById("nome-usuario").textContent = usuario.nome;
  }


  // ---------- Dark Mode ----------
const chk = document.getElementById('checkbox');
const logo = document.getElementById('logo');

// Verifica se já tem preferência salva e aplica
if(localStorage.getItem('modo') === 'dark'){
  document.body.classList.add('dark');
  chk.checked = true;
  logo.src = "/img/mentaally colorido.png"; // versão clara
} else {
  logo.src = "/img/mentaally.png"; // versão escuraa
}

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark');
  
  if(document.body.classList.contains('dark')){
    localStorage.setItem('modo', 'dark');
    logo.src = "/img/mentaally colorido.png"; // troca p/ dark

  } else {
    localStorage.setItem('modo', 'light');
    logo.src = "/img/mentaally.png"; // volta p/ light
  
  }
});




  // Carregar profissionais da API
  fetch("http://localhost:3001/profissionais")
    .then(res => res.json())
    .then(profissionais => {
      const container = document.getElementById("therapists");
      profissionais.forEach(prof => {
        const card = document.createElement("div");
        card.classList.add("therapist-card");
        card.dataset.id = prof.idProfissional;

        card.innerHTML = `
          <h3>${prof.nome_profissional}</h3>
          <p><strong>Email:</strong> ${prof.email_profissional}</p>
          <p><strong>Registro:</strong> ${prof.registro_profissional}</p>
          <p><strong>Especialidade:</strong> ${prof.especialidade}</p>
          <p><strong>Área de Atuação:</strong> ${prof.areaAtuacao}</p>
        `;

        card.addEventListener("click", () => selectCard(card, prof.nome_profissional, prof.especialidade, "R$ 100,00"));
        container.appendChild(card);
      });
    })
    .catch(err => console.error("Erro ao carregar profissionais:", err));
});

// ---------- Steps ----------
let selectedTherapistId = null;
let selectedTherapist = null;
let selectedTag = null;
let selectedPrice = null;
let selectedDate = null;
let selectedTime = null;

// Selecionar card do terapeuta
function selectCard(card, therapist, tag, price) {
  selectedTherapistId = parseInt(card.dataset.id);
  document.querySelectorAll(".therapist-card").forEach(c => c.classList.remove("active"));
  card.classList.add("active");
  selectedTherapist = therapist;
  selectedTag = tag;
  selectedPrice = price;
  document.getElementById("nextBtn1").disabled = false;
}

// Selecionar horário
function selectTime(btn) {
  document.querySelectorAll(".time-btn").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  selectedTime = btn.innerText;
  checkStep2();
}

// Habilitar botão "Próximo" etapa 2
function checkStep2() {
  if (selectedDate && selectedTime) {
    document.getElementById("nextBtn2").disabled = false;
  }
}

// Avançar etapa
function nextStep(step) {
  document.querySelectorAll(".step-content").forEach(c => c.style.display = "none");
  document.querySelector(".step-" + step + "-content").style.display = "block";

  document.querySelectorAll(".step").forEach(s => s.classList.remove("active"));
  document.querySelector(".step-" + step).classList.add("active");

  if (step === 3) {
    const [year, month, day] = selectedDate.split("-").map(Number);
    const localDate = new Date(year, month - 1, day);

    document.getElementById("resumo").innerHTML = `
      <strong>${selectedTherapist}</strong><br>
      <span>${selectedTag}</span><br><br>
      📅 ${localDate.toLocaleDateString("pt-BR", { weekday:"long", year:"numeric", month:"long", day:"numeric" })}<br>
      ⏰ ${selectedTime}<br>
      <strong>Valor: ${selectedPrice}</strong>
    `;
  }
}

// Voltar etapa
function backStep(step) {
  nextStep(step);
}

// ---------- Confirmar Agendamento ----------
function confirmar() {
  const userId = JSON.parse(localStorage.getItem("usuario"))?.id_usuario;
  const observacao = document.querySelector("textarea").value || null;

  if (!selectedTherapistId || !userId || !selectedDate || !selectedTime) {
    alert("Por favor, preencha todas as informações obrigatórias.");
    return;
  }

  fetch("http://localhost:3001/agendamentos", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      PROFISSIONAIS_idProfissional: selectedTherapistId,
      USUARIO_idUsuario: userId,
      data_consulta: selectedDate,
      hora_consulta: selectedTime,
      relato_consulta: null,
      nota_consulta: null,
      observacao_consulta: observacao
    }),
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message || "Agendamento realizado com sucesso!");
    window.location.href = "pagamento.html"; // redireciona para a página desejada
  })
  .catch(err => console.error("Erro ao enviar agendamento:", err));
}

// ---------- Calendário ----------
const monthYear = document.getElementById("monthYear");
const calendarDays = document.getElementById("calendarDays");
const prev = document.getElementById("prev");
const next = document.getElementById("next");

let currentDate = new Date();

function renderCalendar(date) {
  const year = date.getFullYear();
  const month = date.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const lastDay = new Date(year, month + 1, 0).getDate();
  const prevLastDay = new Date(year, month, 0).getDate();
  const months = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
  monthYear.textContent = `${months[month]} ${year}`;
  calendarDays.innerHTML = "";

  const daysOfWeek = ["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"];
  daysOfWeek.forEach(day => {
    const dayName = document.createElement("div");
    dayName.classList.add("day-name");
    dayName.textContent = day;
    calendarDays.appendChild(dayName);
  });

  // Dias anteriores do mês anterior
  for (let x = firstDay; x > 0; x--) {
    const div = document.createElement("div");
    div.classList.add("day","inactive");
    div.textContent = prevLastDay - x + 1;
    calendarDays.appendChild(div);
  }

  const today = new Date();

  // Dias do mês atual
  for (let i = 1; i <= lastDay; i++) {
    const div = document.createElement("div");
    div.classList.add("day");
    div.textContent = i;

    const thisDate = new Date(year, month, i);

    // Deixa o dia atual ativo
    if (year === today.getFullYear() && month === today.getMonth() && i === today.getDate()) {
      div.classList.add("active");
      selectedDate = `${year}-${String(month+1).padStart(2,'0')}-${String(i).padStart(2,'0')}`;
    }

    // Verifica se a data é anterior à atual
    if (thisDate < today) {
      div.classList.add("inactive"); // adiciona classe de indisponível
    } else {
      div.addEventListener("click", () => {
        document.querySelectorAll(".day").forEach(d => d.classList.remove("active"));
        div.classList.add("active");
        selectedDate = `${year}-${String(month+1).padStart(2,'0')}-${String(i).padStart(2,'0')}`;
        checkStep2();
      });
    }

    calendarDays.appendChild(div);
  }
}

// Navegação calendário
prev.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() - 1);
  renderCalendar(currentDate);
});
next.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() + 1);
  renderCalendar(currentDate);
});

// Inicializa calendário
renderCalendar(currentDate);
