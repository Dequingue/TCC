

const chk = document.getElementById('checkbox');

// modo escuro
if(localStorage.getItem('modo') === 'dark'){
  document.body.classList.add('dark');
  chk.checked = true;
}

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark');
  if(document.body.classList.contains('dark')){
    localStorage.setItem('modo', 'dark');
  } else {
    localStorage.setItem('modo', 'light');
  }
});

// envio para backend
document.getElementById("form").addEventListener("submit", function(e){
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();
    const name = document.getElementById("name").value.trim();
    const confirmarSenha = document.getElementById("confirmar-senha").value.trim();
    const terms = document.getElementById("terms").checked;

    // validações
    if (!email.includes("@")) { alert("Digite um e-mail válido."); return; }
    if (password.length < 6) { alert("A senha deve ter no mínimo 6 caracteres."); return; }
    if (name.length < 3) { alert("Nome deve ter no mínimo 3 caracteres."); return; }
    if (confirmarSenha !== password){ alert("As senhas não conferem."); return; }
    if (!terms) { alert("Você precisa aceitar os termos e condições."); return; }

    // envia para Node.js
    fetch("http://localhost:3001/usuarios", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            nome_usuario: name,
            email_usuario: email,
            senha_usuario: password
        })
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message || "Cadastro realizado com sucesso!");
        window.location.href = "login.html";
    })
    .catch(err => {
        console.error(err);
        alert("Erro ao cadastrar usuário. Tente novamente.");
    });
});