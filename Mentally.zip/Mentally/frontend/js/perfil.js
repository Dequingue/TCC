// localStorage Usuario
document.addEventListener("DOMContentLoaded", () => {
    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (usuario && usuario.nome) {
        document.getElementById("nome-usuario").textContent = usuario.nome;
    }

     // Perfis e inputs do formulário (ajuste IDs conforme seu HTML)
  const nomeUsuario = document.getElementById("nome-usuario");
  const nomeCompleto = document.getElementById("nomeCompleto");
  const membroDesde = document.getElementById("membroDesde");
  const inputNome = document.getElementById("inputNome");
  const inputEmail = document.getElementById("inputEmail");
  const inputTelefone = document.getElementById("inputTelefone");
  const inputCPF = document.getElementById("inputCPF"); // Campo CPF

  const profileImage = document.getElementById("profileImage");
  const uploadInput = document.getElementById("uploadInput");
  const form = document.getElementById("formPerfil"); // Seu formulário

  // Preencher dados se usuário logado
  if (usuario) {
    nomeUsuario.textContent = usuario.nome_usuario || usuario.nome || "Visitante";
    if (nomeCompleto) nomeCompleto.textContent = usuario.nome_usuario || usuario.nome || "Visitante";
    if (membroDesde) {
      membroDesde.textContent = usuario.criado_em
        ? `Membro desde ${new Date(usuario.criado_em).toLocaleString('pt-BR', { month: 'long', year: 'numeric' })}`
        : "Membro desde --";
    }
    if (inputNome) inputNome.value = usuario.nome_usuario || usuario.nome || "";
    if (inputEmail) inputEmail.value = usuario.email_usuario || "";
    if (inputTelefone) inputTelefone.value = usuario.telefone || "";
    if (inputCPF) inputCPF.value = usuario.CPF || ""; // CPF
    if (profileImage) profileImage.src = usuario.avatar || "img/perfil siru.jpg";
  }

  // Salvar alterações do perfil com CPF
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();

      if (!usuario || !usuario.id_usuario) {
        alert("Nenhum usuário logado.");
        return;
      }

      const dadosAtualizados = {
        nome_usuario: inputNome.value.trim(),
        email_usuario: inputEmail.value.trim(),
        telefone: inputTelefone.value.trim(),
        CPF: inputCPF.value.trim()
      };

      fetch(`http://localhost:3001/usuarios/${usuario.id_usuario}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dadosAtualizados)
      })
        .then(res => res.json())
        .then(data => {
          alert(data.message || "Perfil atualizado com sucesso!");
          // Atualiza localStorage
          usuario.nome_usuario = dadosAtualizados.nome_usuario;
          usuario.email_usuario = dadosAtualizados.email_usuario;
          usuario.telefone = dadosAtualizados.telefone;
          usuario.CPF = dadosAtualizados.CPF;
          localStorage.setItem("usuario", JSON.stringify(usuario));

          nomeUsuario.textContent = dadosAtualizados.nome_usuario;
          if (nomeCompleto) nomeCompleto.textContent = dadosAtualizados.nome_usuario;
        })
        .catch(err => {
          console.error("Erro ao atualizar perfil:", err);
          alert("Erro ao atualizar perfil. Tente novamente.");
        });
    });
  }
});

const btnMobile = document.getElementById('btn-mobile');
const nav = document.getElementById('nav');
const menu = document.getElementById('menu');
const desktopSocial = document.getElementById('navigation_social');
const desktopIcons = document.getElementById('icons');
const desktopTitle = document.getElementById('title');
const hamburger = document.getElementById('hamburger');

btnMobile.addEventListener('click', toggleMenu);
btnMobile.addEventListener('touchstart', toggleMenu);

function toggleMenu(event) {
  if (event.type === 'touchstart') event.preventDefault();

  nav.classList.toggle('active');
  hamburger.classList.toggle('active');

  const active = nav.classList.contains('active');
  event.currentTarget.setAttribute('aria-expanded', active);
  event.currentTarget.setAttribute('aria-label', active ? 'Fechar Menu' : 'Abrir Menu');

  // Quando abrir o menu mobile
  if (active && window.innerWidth <= 1100) {
    // Adiciona o título
    if (!document.getElementById('mobile-title')) {
      const mobileTitle = desktopTitle.cloneNode(true);
      mobileTitle.id = 'mobile-title';
      menu.prepend(mobileTitle);
    }

    
    // Adiciona os ícones sociais
    if (!document.getElementById('mobile-social')) {
      const mobileSocial = desktopSocial.cloneNode(true);
      mobileSocial.id = 'mobile-social';
      menu.appendChild(mobileSocial);
    }
    
    // Adiciona os ícones
    if (!document.getElementById('mobile-icons')) {
      const mobileIcons = desktopIcons.cloneNode(true);
      mobileIcons.id = 'mobile-icons';
      menu.appendChild(mobileIcons);
    }
  }

  // Quando fechar o menu mobile
  if (!active) {
    const mobileTitle = document.getElementById('mobile-title');
    const mobileSocial = document.getElementById('mobile-social');
    const mobileIcons = document.getElementById('mobile-icons');

    if (mobileTitle) mobileTitle.remove();
    if (mobileSocial) mobileSocial.remove();
    if (mobileIcons) mobileIcons.remove();
  }
}



//modo escuro- modo claro
const chk = document.getElementById('checkbox');
const logo = document.getElementById('logo'); // agora pega o <img>

// Verifica se já tem preferência salva e aplica
if(localStorage.getItem('modo') === 'dark'){
  document.body.classList.add('dark');
  chk.checked = true;
  logo.src = "img/mentaally-colorido.png"; // versão clara
} else {
  logo.src = "img/mentaally.png"; // versão escuraa
}

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark');
  
  if(document.body.classList.contains('dark')){
    localStorage.setItem('modo', 'dark');
    logo.src = "img/mentaally-colorido.png"; // troca p/ dark

  } else {
    localStorage.setItem('modo', 'light');
    logo.src = "img/mentaally.png"; // volta p/ light
  
  }
});


  // --- Tabs ---
  const tabs = document.querySelectorAll(".tab-btn");
  const contents = document.querySelectorAll(".tab-content");

  tabs.forEach(btn => {
    btn.addEventListener("click", () => {
      tabs.forEach(b => b.classList.remove("active"));
      contents.forEach(c => c.classList.remove("active"));

      btn.classList.add("active");
      document.getElementById(btn.dataset.tab).classList.add("active");
    });
  });

  // --- Foto de perfil ---
  const profileImage = document.getElementById("profileImage");
  const uploadInput = document.getElementById("uploadInput");
  const modal = document.getElementById("modal");
  const modalImage = document.getElementById("modalImage");

  // Carregar imagem salva no LocalStorage
  window.addEventListener("load", () => {
    const savedImage = localStorage.getItem("profileImage");
    if (savedImage) {
      profileImage.src = savedImage;
    }
  });

  // Trocar a foto
  uploadInput.addEventListener("change", (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imgData = e.target.result;
        profileImage.src = imgData;

        // Salvar no LocalStorage
        localStorage.setItem("profileImage", imgData);
      };
      reader.readAsDataURL(file);
    }
  });

  // Abrir modal
  profileImage.addEventListener("click", () => {
    modal.style.display = "flex";
    modalImage.src = profileImage.src;
  });

  // Fechar modal
  modal.addEventListener("click", () => {
    modal.style.display = "none";
  });


document.querySelectorAll(".toggle-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    const ativo = btn.classList.toggle("ativo");
    btn.classList.toggle("desativado", !ativo);
    btn.textContent = ativo ? "Ativado" : "Desativado";
  });
});
  


// Excluir conta
function excluirConta() {
  const confirmar = confirm("⚠️ Tem certeza que deseja excluir sua conta permanentemente?");
  if (confirmar) {
    alert("🚨 Conta excluída com sucesso (exemplo).");
  }
}



