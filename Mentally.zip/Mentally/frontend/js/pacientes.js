document.addEventListener("DOMContentLoaded", () => {
  const pacientesList = document.getElementById("pacientesList");
  const addPacienteBtn = document.getElementById("addPacienteBtn");
  const modal = document.getElementById("modal");
  const closeModal = document.getElementById("closeModal");
  const pacienteForm = document.getElementById("pacienteForm");

  let pacientes = JSON.parse(localStorage.getItem("pacientes")) || [];
  let editIndex = null;

  // Função para renderizar a lista de pacientes
  function renderPacientes() {
    pacientesList.innerHTML = "";

    if (pacientes.length === 0) {
      pacientesList.innerHTML = `<p style="text-align:center; color:#ccc;">Nenhum paciente cadastrado.</p>`;
      return;
    }

    pacientes.forEach((paciente, index) => {
      const card = document.createElement("div");
      card.classList.add("paciente-card");

      card.innerHTML = `
        <div class="paciente-info">
          <span><b>Nome:</b> ${paciente.nome}</span>
          <span><b>Email:</b> ${paciente.email}</span>
          <span><b>Telefone:</b> ${paciente.telefone}</span>
          <span><b>Data de Nascimento:</b> ${paciente.nascimento}</span>
        </div>
        <div class="paciente-actions">
          <button class="btn-editar">Editar</button>
          <button class="btn-excluir">Excluir</button>
        </div>
      `;

      // Botão editar
      card.querySelector(".btn-editar").addEventListener("click", () => {
        openModal();
        editIndex = index;
        pacienteForm.nome.value = paciente.nome;
        pacienteForm.email.value = paciente.email;
        pacienteForm.telefone.value = paciente.telefone;
        pacienteForm.nascimento.value = paciente.nascimento;
      });

      // Botão excluir
      card.querySelector(".btn-excluir").addEventListener("click", () => {
        if (confirm(`Deseja realmente excluir o paciente ${paciente.nome}?`)) {
          pacientes.splice(index, 1);
          savePacientes();
          renderPacientes();
        }
      });

      pacientesList.appendChild(card);
    });
  }

  // Salvar no localStorage
  function savePacientes() {
    localStorage.setItem("pacientes", JSON.stringify(pacientes));
  }

  // Abrir modal
  function openModal() {
    modal.style.display = "flex";
  }

  // Fechar modal
  function closeModalFunc() {
    modal.style.display = "none";
    pacienteForm.reset();
    editIndex = null;
  }

  // Adicionar novo paciente
  addPacienteBtn.addEventListener("click", openModal);
  closeModal.addEventListener("click", closeModalFunc);

  // Submit do formulário
  pacienteForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const novoPaciente = {
      nome: pacienteForm.nome.value,
      email: pacienteForm.email.value,
      telefone: pacienteForm.telefone.value,
      nascimento: pacienteForm.nascimento.value,
    };

    if (editIndex !== null) {
      pacientes[editIndex] = novoPaciente; // Editar paciente existente
    } else {
      pacientes.push(novoPaciente); // Adicionar novo paciente
    }

    savePacientes();
    renderPacientes();
    closeModalFunc();
  });

  // Inicializar lista
  renderPacientes();

  // Fechar modal clicando fora do conteúdo
  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeModalFunc();
  });
});
