document.addEventListener("DOMContentLoaded", () => {
  const pacientesList = document.getElementById("listaPacientes");
  const modal = document.getElementById("modalPaciente");
  const nomePerfil = document.getElementById("nomePerfil");
  const telefonePerfil = document.getElementById("telefonePerfil");
  const nascimentoPerfil = document.getElementById("nascimentoPerfil");
  const fotoPaciente = document.getElementById("fotoPaciente");

  // Recupera o profissional logado usando a chave correta
  const profissionalLogado = JSON.parse(localStorage.getItem("profissional"));
  const idProfissional = profissionalLogado ? profissionalLogado.idProfissional : null;

  if (!idProfissional) {
    pacientesList.innerHTML = `<p style="text-align:center; color:#ccc;">Nenhum profissional logado!</p>`;
    return;
  }

  // Função para buscar pacientes do backend
  async function carregarPacientes() {
    try {
      const response = await fetch(`http://localhost:3001/pacientes/${idProfissional}`);
      const pacientes = await response.json();
      renderPacientes(pacientes);
    } catch (error) {
      console.error("Erro ao carregar pacientes:", error);
      pacientesList.innerHTML = `<p style="text-align:center; color:#ccc;">Não foi possível carregar os pacientes.</p>`;
    }
  }

  // Renderiza pacientes
  function renderPacientes(pacientes) {
    pacientesList.innerHTML = "";

    if (!pacientes || pacientes.length === 0) {
      pacientesList.innerHTML = `<p style="text-align:center; color:#ccc;">Nenhum paciente cadastrado.</p>`;
      return;
    }

    pacientes.forEach(paciente => {
      const card = document.createElement("div");
      card.classList.add("paciente-card");

      const foto = paciente.avatar_url || "img/perfil siru.jpg";

    // Alterar dentro do renderPacientes:
        card.innerHTML = `
            <div class="paciente-info" style="display:flex; align-items:center;">
            <img src="${foto}" alt="Foto do paciente" style="width:60px;height:60px;border-radius:50%;margin-right:10px;">
            <div>
              <span><b>Nome:</b> ${paciente.nome}</span>
               <span><b>Telefone:</b> ${paciente.telefone || '-'}</span>
                <span><b>Data de Nascimento:</b> ${paciente.data_nascimento ? new Date(paciente.data_nascimento).toLocaleDateString() : '-'}</span>
                </div>
               </div>
          `;

      // Abrir modal ao clicar no card
      card.addEventListener("click", () => {
          nomePerfil.textContent = paciente.nome;
          telefonePerfil.textContent = paciente.telefone || '-';
          nascimentoPerfil.textContent = paciente.data_nascimento ? new Date(paciente.data_nascimento).toLocaleDateString() : '-';

        fotoPaciente.src = foto;
        modal.style.display = "flex";
      });

      pacientesList.appendChild(card);
    });
  }

  // Fechar modal
  modal.addEventListener("click", (e) => {
    if (e.target === modal) modal.style.display = "none";
  });

  // Carregar pacientes ao iniciar
  carregarPacientes();
});
