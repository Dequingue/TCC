document.getElementById("form-login").addEventListener("submit", function(e){
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    if (!email || !password) {
        alert("Preencha todos os campos.");
        return;
    }

    fetch("http://localhost:3001/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email:email, senha: password })
    })
    .then(res => {
        console.log("Status da resposta login:", res.status);
        return res.json();
    })
    .then(data => {
        console.log("Resposta do servidor no login:", data);
        if (data.tipoConta === "usuario") {
            alert(`Bem-vindo, ${data.usuario.nome_usuario}!`);
            // opcional: salvar no localStorage
            window.location.href = "pagina_principal.html";
        } else if (data.tipoConta === "profissional") {
            alert(`Bem-vindo, ${data.usuario.nome_profissional}!`);
            window.location.href = "profissional-principal.html";
        } else {
            alert(data.message || "Email ou senha incorretos.");
        }
    })
    .catch(err => {
        console.error("Erro na requisição de login:", err);
        alert("Erro ao tentar realizar login. Tente novamente.");
    });
});

