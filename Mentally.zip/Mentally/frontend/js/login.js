document.addEventListener("DOMContentLoaded", () => {
  const chk = document.getElementById('checkbox');

  // ===== MODO ESCURO =====
  if (localStorage.getItem('modo') === 'dark') {
    document.body.classList.add('dark');
    if(chk) chk.checked = true;
  }

  if(chk) {
    chk.addEventListener('change', () => {
      document.body.classList.toggle('dark');
      localStorage.setItem('modo', document.body.classList.contains('dark') ? 'dark' : 'light');
    });
  }

  // ===== LOGIN =====
  const formLogin = document.getElementById("form-login");
  if(formLogin){
    formLogin.addEventListener("submit", function(e){
      e.preventDefault();

      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value.trim();

      if (!email || !password) {
        alert("Preencha todos os campos.");
        return;
      }

      fetch("http://localhost:3001/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email, senha: password })
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          if (data.tipo === "usuario") {
            localStorage.setItem("usuario", JSON.stringify(data.usuario));
            if (!data.usuario.CPF || data.usuario.CPF.trim() === "") {
              alert("⚠️ Você ainda não completou seu cadastro. Por favor, preencha seu CPF.");
              window.location.href = "Perfil.html";
            } else {
              alert(`Bem-vindo, ${data.usuario.nome_usuario}!`);
              window.location.href = "pagina_principal.html";
            }
          } else if (data.tipo === "profissional") {
            localStorage.setItem("profissional", JSON.stringify(data.profissional));
            // Corrigido: sobre_mim é propriedade, não função
            if (!data.profissional.sobre_mim || data.profissional.sobre_mim.trim() === "") {
              alert("⚠️ Complete seu cadastro.");
              window.location.href = "perfil-profissional.html";
            } else {
              alert(`Bem-vindo, Dr(a). ${data.profissional.nome_profissional}!`);
              window.location.href = "profissional-principal.html";
            }
          }
        } else {
          alert(data.message || "E-mail ou senha inválidos.");
        }
      })
      .catch(err => {
        console.error("Erro ao logar:", err);
        alert("Erro de conexão com o servidor.");
      });
    });
  }
});
