document.getElementById("form-login").addEventListener("submit", function(e){
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    if (!email || !password) {
        alert("Preencha todos os campos.");
        return;
    }

    fetch("http://localhost:3001/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email_usuario: email, senha_usuario: password })
    })
    .then(res => res.json())
    .then(data => {
        if (data.usuario) {  // Aqui estamos verificando se o backend retornou o usuário
            alert(`Bem-vindo, ${data.usuario.nome_usuario}!`);
            localStorage.setItem("usuario", JSON.stringify(data.usuario));
            window.location.href = "home.html"; // redireciona para home.html
        } else {
            alert(data.message || "Email ou senha incorretos.");
        }
    })
    .catch(err => {
        console.error(err);
        alert("Erro ao tentar realizar login. Tente novamente.");
    });
});
