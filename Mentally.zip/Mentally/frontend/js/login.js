document.getElementById("form-login").addEventListener("submit", function(e) {
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    if (!email || !password) {
        alert("Preencha todos os campos.");
        return;
    }

    fetch("http://localhost:3001/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, senha: password }) // envio correto
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            if (data.tipo === "usuario") {
                // Salva usuário logado
                localStorage.setItem("usuarioLogado", JSON.stringify(data.usuario));
                alert(`Bem-vindo, ${data.usuario.nome_usuario}!`);
                window.location.href = "home.html"; // página do usuário
            } else if (data.tipo === "profissional") {
                // Salva profissional logado
                localStorage.setItem("profissionalLogado", JSON.stringify(data.profissional));
                alert(`Bem-vindo, ${data.profissional.nome_profissional}!`);
                window.location.href = "profissional-principal.html"; // página do profissional
            }
        } else {
            alert(data.message || "E-mail ou senha incorretos.");
        }
    })
    .catch(err => {
        console.error("Erro ao tentar realizar login:", err);
        alert("Erro ao tentar realizar login. Tente novamente.");
    });
});
