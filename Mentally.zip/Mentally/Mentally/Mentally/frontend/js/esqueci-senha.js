document.getElementById("form-esqueci-senha").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("email").value.trim();
  if (!email) return alert("Digite um e-mail.");

  try {
    const res = await fetch("http://localhost:3001/esqueci-senha", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({email})
    });
    const data = await res.json();
    if (data.success) {
      // Redireciona para redefinir senha com ID ou token
      window.location.href = data.redirect;
    } else {
      alert(data.message);
    }
  } catch(err) {
    console.error(err);
    alert("Erro ao verificar e-mail.");
  }
});