
const btnMobile = document.getElementById('btn-mobile');
const nav = document.getElementById('nav');
const menu = document.getElementById('menu');
const desktopSocial = document.getElementById('navigation_social');
const desktopIcons = document.getElementById('icons');
const desktopTitle = document.getElementById('title');
const hamburger = document.getElementById('hamburger');

btnMobile.addEventListener('click', toggleMenu);
btnMobile.addEventListener('touchstart', toggleMenu);

function toggleMenu(event) {
  if (event.type === 'touchstart') event.preventDefault();

  nav.classList.toggle('active');
  hamburger.classList.toggle('active');

  const active = nav.classList.contains('active');
  event.currentTarget.setAttribute('aria-expanded', active);
  event.currentTarget.setAttribute('aria-label', active ? 'Fechar Menu' : 'Abrir Menu');

  // Quando abrir o menu mobile
  if (active && window.innerWidth <= 1100) {
    // Adiciona o título
    if (!document.getElementById('mobile-title')) {
      const mobileTitle = desktopTitle.cloneNode(true);
      mobileTitle.id = 'mobile-title';
      menu.prepend(mobileTitle);
    }

    
    // Adiciona os ícones sociais
    if (!document.getElementById('mobile-social')) {
      const mobileSocial = desktopSocial.cloneNode(true);
      mobileSocial.id = 'mobile-social';
      menu.appendChild(mobileSocial);
    }
    
    // Adiciona os ícones
    if (!document.getElementById('mobile-icons')) {
      const mobileIcons = desktopIcons.cloneNode(true);
      mobileIcons.id = 'mobile-icons';
      menu.appendChild(mobileIcons);
    }
  }

  // Quando fechar o menu mobile
  if (!active) {
    const mobileTitle = document.getElementById('mobile-title');
    const mobileSocial = document.getElementById('mobile-social');
    const mobileIcons = document.getElementById('mobile-icons');

    if (mobileTitle) mobileTitle.remove();
    if (mobileSocial) mobileSocial.remove();
    if (mobileIcons) mobileIcons.remove();
  }
}

document.addEventListener("DOMContentLoaded", () => {
      // Modo escuro
      const chk = document.getElementById("checkbox");
      if (localStorage.getItem("modo") === "dark") {
        document.body.classList.add("dark");
        chk.checked = true;
      }
      chk.addEventListener("change", () => {
        document.body.classList.toggle("dark");
        localStorage.setItem(
          "modo",
          document.body.classList.contains("dark") ? "dark" : "light"
        );
      });

      // Elementos
      const nomeUsuario = document.getElementById("nome-usuario");
      const nomeCompleto = document.getElementById("nomeCompleto");
      const membroDesde = document.getElementById("membroDesde");
      const inputNome = document.getElementById("inputNome");
      const inputEmail = document.getElementById("inputEmail");
      const inputTelefone = document.getElementById("inputTelefone");
      const inputCPF = document.getElementById("inputCPF");
      const profileImage = document.getElementById("profileImage");
      const uploadInput = document.getElementById("uploadInput");
      const form = document.getElementById("formPerfil");
      const inputData = document.getElementById("dtNascimento")
      const inputPlano = document.getElementById("plano_tratamento")

      // Pegar usuário logado do localStorage
      const user = JSON.parse(localStorage.getItem("usuario"));

      if (user) {
        // --- Preenche os inputs com dados do localStorage imediatamente ---
        nomeUsuario.textContent = user.nome_usuario || "";
        nomeCompleto.textContent = user.nome_usuario || "";
        inputNome.value = user.nome_usuario || "";
        inputEmail.value = user.email_usuario || "";
        inputTelefone.value = user.telefone || "";
        inputCPF.value = user.cpf || "";
        inputData.value = user.dtNascimento || "";
        inputPlano.value = user.plano_tratamento || "";
        membroDesde.textContent = "Membro desde " + new Date(user.data_criacao).toLocaleDateString("pt-BR");



        if (user.avatar_url) {
          profileImage.src = "http://localhost:3001" + user.avatar_url;
        }

        // --- Depois busca no backend os dados atualizados ---
        fetch(`http://localhost:3001/usuarios/${user.id_usuario}`)
          .then(response => response.json())
          .then(dadosAtualizados => {
            // Atualiza localStorage com os dados mais recentes
            localStorage.setItem("usuario", JSON.stringify(dadosAtualizados));

            nomeUsuario.textContent = dadosAtualizados.nome_usuario;
            nomeCompleto.textContent = dadosAtualizados.nome_usuario;
            inputNome.value = dadosAtualizados.nome_usuario;
            inputEmail.value = dadosAtualizados.email_usuario;
            inputTelefone.value = dadosAtualizados.telefone || "";
            inputCPF.value = dadosAtualizados.cpf || "";
            if (dadosAtualizados.dtNascimento) {
              // Se vier "2025-09-09T00:00:00.000Z"
              inputData.value = dadosAtualizados.dtNascimento.split("T")[0];
            } else {
              inputData.value = "";
            }

            inputPlano.value = dadosAtualizados.plano_tratamento || "";
            membroDesde.textContent = "Membro desde " + new Date(dadosAtualizados.data_criacao).toLocaleDateString("pt-BR");

            if (dadosAtualizados.avatar_url) {
              profileImage.src = "http://localhost:3001" + dadosAtualizados.avatar_url;
            }
          })
          .catch(error => {
            console.error("Erro ao buscar dados atualizados do usuário:", error);
          });
      }


      // Upload da imagem
      uploadInput.addEventListener("change", async () => {
        if (uploadInput.files.length > 0) {
          const file = uploadInput.files[0];
          const formData = new FormData();
          formData.append("avatar", file);

          try {
            const response = await fetch("http://localhost:3001/usuarios/avatar", {
              method: "POST",
              body: formData,
            });
            if (response.ok) {
              alert("Imagem enviada com sucesso");
              const data = await response.json();
              profileImage.src = "http://localhost:3001" + data.avatar_url;
              // Atualize localStorage se necessário
              user.avatar_url = data.avatar_url;
              localStorage.setItem("usuario", JSON.stringify(user));
            } else {
              alert("Erro ao enviar imagem");
            }
          } catch (error) {
            alert("Erro na conexão: " + error.message);
          }
        }
      });

      // Modal da imagem
      const modal = document.getElementById("modal");
      const modalImage = document.getElementById("modalImage");

      profileImage.addEventListener("click", () => {
        modalImage.src = profileImage.src;
        modal.style.display = "flex";
      });

      modal.addEventListener("click", () => {
        modal.style.display = "none";
      });

      // Trocar abas
      const tabButtons = document.querySelectorAll(".tab-btn");
      const tabContents = document.querySelectorAll(".tab-content");

      tabButtons.forEach((btn) => {
        btn.addEventListener("click", () => {
          tabButtons.forEach((b) => b.classList.remove("active"));
          tabContents.forEach((content) => content.classList.remove("active"));

          btn.classList.add("active");
          const tab = btn.getAttribute("data-tab");
          document.getElementById(tab).classList.add("active");
        });
      });

      // Salvar alterações do perfil
      form.addEventListener("submit", async (e) => {
        e.preventDefault();

        // Validação básica do CPF
        if (!inputCPF.value.match(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/)) {
          alert("CPF inválido. Use o formato 000.000.000-00");
          return;
        }

        // Dados atualizados
        const dadosAtualizados = {
          nome_usuario: inputNome.value,
          email_usuario: inputEmail.value,
          telefone: inputTelefone.value,
          cpf: inputCPF.value,
          dtNascimento: inputData.value,
          plano_tratamento: inputPlano.value
        };

        try {
          const response = await fetch(
            `http://localhost:3001/usuarios/${user.id_usuario}`,
            {
              method: "PUT",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify(dadosAtualizados),
            }
          );

          if (response.ok) {
            alert("Perfil atualizado com sucesso!");
            // Atualizar localStorage
            Object.assign(user, dadosAtualizados);
            localStorage.setItem("usuario", JSON.stringify(user));
            nomeUsuario.textContent = dadosAtualizados.nome_usuario;
            nomeCompleto.textContent = dadosAtualizados.nome_usuario;
          } else {
            alert("Erro ao atualizar perfil.");
          }
        } catch (error) {
          alert("Erro na conexão: " + error.message);
        }
      });

      // Função para exclusão de conta
      window.excluirConta = async () => {
        if (confirm("Tem certeza que deseja excluir sua conta? Essa ação não pode ser desfeita.")) {
          try {
            const user = JSON.parse(localStorage.getItem("usuario"));
            const response = await fetch(`http://localhost:3001/usuarios/${user.id_usuario}`, {
              method: "DELETE",
            });
            if (response.ok) {
              alert("Conta excluída com sucesso!");
              localStorage.removeItem("usuario");
              window.location.href = "index.html"; // Redirecionar para página inicial/login
            } else {
              const data = await response.json();
              alert("Erro: " + data.message);
            }
          } catch (error) {
            alert("Erro na conexão: " + error.message);
          }
        }
      };

    });


