document.addEventListener("DOMContentLoaded", () => {
  const agendaList = document.getElementById("agendaList");
  const modal = document.getElementById("modal");
  const closeModalBtn = document.getElementById("closeModal");
  const agendamentoForm = document.getElementById("agendamentoForm");

  const inputPaciente = document.getElementById("nomePaciente");
  const inputData = document.getElementById("dataAgendamento");
  const inputHora = document.getElementById("horaAgendamento");

  const addAgendamentoBtn = document.getElementById("addAgendamentoBtn");

  // Recupera o profissional logado
  const profissionalLogado = JSON.parse(localStorage.getItem("profissional"));
  const idProfissional = profissionalLogado ? profissionalLogado.idProfissional : null;

  if (!idProfissional) {
    if (agendaList) agendaList.innerHTML = `<p style="text-align:center; color:#ccc;">Nenhum profissional logado!</p>`;
    return;
  }

  // Função para carregar agendamentos
  async function carregarAgendamentos() {
    if (!agendaList) return;
    try {
      // 🚀 Rota ajustada
      const response = await fetch(`http://localhost:3001/agendamentos/profissional/${idProfissional}`);
      const agendamentos = await response.json();
      renderAgenda(agendamentos);
    } catch (error) {
      console.error("Erro ao carregar agendamentos:", error);
      agendaList.innerHTML = `<p style="text-align:center; color:#ccc;">Não foi possível carregar os agendamentos.</p>`;
    }
  }

// Renderiza agendamentos
function renderAgenda(agendamentos) {
  if (!agendaList) return;
  console.log("Dados recebidos do backend:", agendamentos);

  agendaList.innerHTML = "";

  if (!agendamentos || agendamentos.length === 0) {
    agendaList.innerHTML = `<p style="text-align:center; color:#ccc;">Nenhum agendamento registrado</p>`;
    return;
  }

  agendamentos.forEach(ag => {
    console.log("Agendamento:", ag);

    const item = document.createElement("div");
    item.className = "agendamento-item";

    // Dados do usuário (vem do JOIN no backend)
    const nomePaciente = ag.nome_usuario || ag.nome || "-";
    const cpfPaciente = ag.cpf_usuario || "-";
    const emailPaciente = ag.email_usuario || "-";
    const telefonePaciente = ag.telefone_usuario || "-";
    const dataConsulta = ag.data_consulta ? new Date(ag.data_consulta).toLocaleDateString() : "-";
    const horaConsulta = ag.hora_consulta || "-";
    const observacao = ag.observacao_consulta || "Nenhuma";

    item.innerHTML = `
      <div class="agendamento-card">
        <div class="agendamento-header">
          <h3>${nomePaciente}</h3>
        </div>

        <div class="agendamento-section">
          <h4>Dados do Paciente</h4>
          <p><b>CPF:</b> ${cpfPaciente}</p>
          <p><b>Email:</b> ${emailPaciente}</p>
          <p><b>Telefone:</b> ${telefonePaciente}</p>
        </div>

        <div class="agendamento-section">
          <h4>Consulta</h4>
          <p><b>Data:</b> ${dataConsulta}</p>
          <p><b>Hora:</b> ${horaConsulta}</p>
          <p><b>Observação:</b> ${observacao}</p>
        </div>

        <div class="agendamento-actions">
          <button class="entrar">Entrar na Consulta</button>
        </div>
      </div>
    `;

    const entrarBtn = item.querySelector(".entrar");
    if (entrarBtn) {
      entrarBtn.addEventListener("click", () => {
        alert(`Entrando na consulta com ${nomePaciente} às ${horaConsulta} do dia ${dataConsulta}`);
      });
    }

    agendaList.appendChild(item);
  });
}


  // Abrir modal de novo agendamento
  if (addAgendamentoBtn && modal) {
    addAgendamentoBtn.addEventListener("click", () => modal.style.display = "flex");
  }

  // Fechar modal
  if (closeModalBtn && modal) {
    closeModalBtn.addEventListener("click", () => modal.style.display = "none");
    modal.addEventListener("click", e => { if (e.target === modal) modal.style.display = "none"; });
  }

  // Enviar formulário de agendamento
  if (agendamentoForm) {
    agendamentoForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const paciente = inputPaciente ? inputPaciente.value : "";
      const data = inputData ? inputData.value : "";
      const hora = inputHora ? inputHora.value : "";

      if (!paciente || !data || !hora) {
        alert("Preencha todos os campos!");
        return;
      }

      try {
        // Buscar paciente selecionado
        const pacienteObj = JSON.parse(localStorage.getItem("pacienteSelecionado")) || null;
        const idUsuario = pacienteObj ? pacienteObj.idUsuario : null;

        await fetch("http://localhost:3001/agendamentos", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            PROFISSIONAIS_idProfissional: idProfissional,
            USUARIO_idUsuario: idUsuario,
            data_consulta: data,
            hora_consulta: hora
          })
        });

        if (modal) modal.style.display = "none";
        carregarAgendamentos();
      } catch (err) {
        console.error("Erro ao salvar agendamento:", err);
        alert("Não foi possível salvar o agendamento.");
      }
    });
  }

  // Carrega agenda ao iniciar
  carregarAgendamentos();
});
