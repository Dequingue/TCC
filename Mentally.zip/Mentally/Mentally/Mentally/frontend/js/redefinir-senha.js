document.addEventListener("DOMContentLoaded", () => {
  // Modo escuro
  const chk = document.getElementById("checkbox");
  if (localStorage.getItem("modo") === "dark") {
    document.body.classList.add("dark");
    if (chk) chk.checked = true;
  }
  if (chk) {
    chk.addEventListener("change", () => {
      document.body.classList.toggle("dark");
      localStorage.setItem("modo", document.body.classList.contains("dark") ? "dark" : "light");
    });
  }

  // ===== REDEFINIR SENHA =====
  const form = document.getElementById("form-redefinir-senha");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const novaSenha = document.getElementById("nova-senha").value.trim();
    const confirmarSenha = document.getElementById("confirmar-senha").value.trim();

    if (!novaSenha || !confirmarSenha) {
      alert("⚠️ Preencha todos os campos.");
      return;
    }

    if (novaSenha !== confirmarSenha) {
      alert("❌ As senhas não coincidem.");
      return;
    }

    // Pega token da URL
    const params = new URLSearchParams(window.location.search);
    const token = params.get("token");

    if (!token) {
      alert("Token inválido.");
      return;
    }

    try {
      const res = await fetch("http://localhost:3001/redefinir-senha", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, novaSenha })
      });
      const data = await res.json();

      if (data.success) {
        alert("✅ Senha redefinida com sucesso!");
        window.location.href = "login.html";
      } else {
        alert(data.message || "❌ Não foi possível redefinir a senha.");
      }
    } catch (err) {
      console.error("Erro ao redefinir senha:", err);
      alert("Erro de conexão com o servidor.");
    }
  });
});