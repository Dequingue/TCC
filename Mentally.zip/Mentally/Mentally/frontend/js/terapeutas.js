// ---------- Mostrar nome do usuário ----------
document.addEventListener("DOMContentLoaded", () => {
    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (usuario && usuario.nome) {
        document.getElementById("nome-usuario").textContent = usuario.nome;
    }

    // ---------- Buscar profissionais do backend ----------
    fetch("http://localhost:3001/profissionais")
        .then(res => res.json())
        .then(terapeutas => {
            const mainContent = document.querySelector(".main-content > div:first-child");
            mainContent.innerHTML = ""; // limpa conteúdo existente

            if (!terapeutas || terapeutas.length === 0) {
                mainContent.innerHTML = `<p style="text-align:center; color:#ccc;">Nenhum profissional cadastrado.</p>`;
                return;
            }

            terapeutas.forEach(t => {
                const card = document.createElement("div");
                card.className = "therapist-card";

                
              const foto = "/img/silhueta.png"; // silhueta


                card.innerHTML = `
                    <img src="${foto}" alt="${t.nome_profissional}">
                    <div class="therapist-info">
                        <h3>${t.nome_profissional}</h3>
                        <span class="tag">${t.especialidade}</span>
                        <p>Registro: ${t.registro_profissional}</p>
                        <p>Área de Atuação: ${t.areaAtuacao}</p>
                        <p>Descrição: Especialista qualificado disponível para atendimento.</p>
                        <div class="rating">⭐ 4.9 - Online & Presencial</div>
                        <p>Horários disponíveis: 09:00, 10:00, 11:00, 14:00 +2 mais</p>
                        <div class="buttons">
                            <button class="btn btn-primary">Agendar Consulta</button>
                            <button class="btn btn-secondary">Ver Perfil Completo</button>
                        </div>
                    </div>
                `;

                mainContent.appendChild(card);
            });
        })
        .catch(err => {
            console.error("Erro ao carregar profissionais:", err);
            const mainContent = document.querySelector(".main-content > div:first-child");
            mainContent.innerHTML = `<p style="text-align:center; color:#ccc;">Erro ao carregar profissionais.</p>`;
        });
});

// ---------- Menu Mobile ----------
const btnMobile = document.getElementById('btn-mobile');
const nav = document.getElementById('nav');
const menu = document.getElementById('menu');
const desktopSocial = document.getElementById('navigation_social');
const desktopIcons = document.getElementById('icons');
const desktopTitle = document.getElementById('title');
const hamburger = document.getElementById('hamburger');

btnMobile.addEventListener('click', toggleMenu);
btnMobile.addEventListener('touchstart', toggleMenu);

function toggleMenu(event) {
    if (event.type === 'touchstart') event.preventDefault();
    nav.classList.toggle('active');
    hamburger.classList.toggle('active');
    const active = nav.classList.contains('active');
    event.currentTarget.setAttribute('aria-expanded', active);
    event.currentTarget.setAttribute('aria-label', active ? 'Fechar Menu' : 'Abrir Menu');
}

// ---------- Modo escuro ----------
const chk = document.getElementById('checkbox');
const logo = document.getElementById('logo');

if(localStorage.getItem('modo') === 'dark'){
  document.body.classList.add('dark');
  chk.checked = true;
}

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark');
  if(document.body.classList.contains('dark')){
    localStorage.setItem('modo', 'dark');
    logo.src = "/img/mentaally colorido.png";
  } else {
    localStorage.setItem('modo', 'light');
    logo.src = "/img/mentaally.png";
  }
});
