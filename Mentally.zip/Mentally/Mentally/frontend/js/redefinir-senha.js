document.addEventListener("DOMContentLoaded", async () => {
  const params = new URLSearchParams(window.location.search);
  const token = params.get("token");
  const mensagem = document.getElementById("mensagem");

  if (!token) {
    mensagem.textContent = "Token inválido.";
    return;
  }

  // Valida o token
  try {
    const res = await fetch(`http://localhost:3001/validar-token/${token}`);
    const data = await res.json();

    if (!data.success) {
      mensagem.textContent = "Token expirado ou inválido.";
      return;
    }
  } catch (err) {
    console.error(err);
    mensagem.textContent = "Erro ao validar token.";
    return;
  }

  // Envia nova senha
  document.getElementById("form-redefinir").addEventListener("submit", async (e) => {
    e.preventDefault();

    const s1 = document.getElementById("senha1").value.trim();
    const s2 = document.getElementById("senha2").value.trim();

    if (s1 !== s2) {
      mensagem.textContent = "As senhas não coincidem.";
      return;
    }

    if (s1.length < 6) {
      mensagem.textContent = "A senha deve ter pelo menos 6 caracteres.";
      return;
    }

    try {
      const res = await fetch("http://localhost:3001/redefinir-senha", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, novaSenha: s1 })
      });

      const data = await res.json();

      if (data.success) {
        mensagem.textContent = "Senha alterada com sucesso! Redirecionando...";
        setTimeout(() => {
          window.location.href = "login.html";
        }, 1500);
      } else {
        mensagem.textContent = data.message;
      }
    } catch (err) {
      console.error(err);
      mensagem.textContent = "Erro ao redefinir senha.";
    }
  });
});
