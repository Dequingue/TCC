document.addEventListener("DOMContentLoaded", () => {
  const chk = document.getElementById("checkbox");
  const nomeCompleto = document.getElementById("nomeCompleto");
  const nomeUsuarioHeader = document.getElementById("nome-usuario");
  const profileImage = document.getElementById("profileImage");
  const uploadInput = document.getElementById("uploadInput");
  const inputNome = document.getElementById("inputNome");
  const inputEmail = document.getElementById("inputEmail");
  const inputSobre = document.getElementById("inputSobre");
  const inputEspecialidade = document.getElementById("inputEspecialidade");
  const inputAreaAtuacao = document.getElementById("inputAreaAtuacao");
  const formPerfil = document.getElementById("formPerfil");
  const membroDesde = document.getElementById("membroDesde");

  // Função para normalizar texto (remove acentos e espaços em excesso)
  function normalizar(texto) {
    return texto
      .normalize("NFD")                     // Separar acentos
      .replace(/[\u0300-\u036f]/g, "")     // Remover acentos
      .trim()
      .toLowerCase();                      // Converter para minúsculas
  }

  // ===== MODO ESCURO =====
  if (chk) {
    if (localStorage.getItem("modo") === "dark") {
      document.body.classList.add("dark");
      chk.checked = true;
    }
    chk.addEventListener("change", () => {
      document.body.classList.toggle("dark");
      localStorage.setItem("modo", document.body.classList.contains("dark") ? "dark" : "light");
    });
  }

  // ===== CARREGAR LISTAS DE ESPECIALIDADES E ÁREAS =====
  let especialidades = [];
  let areasAtuacao = [];

  let listasCarregadas = false;
  async function carregarListas() {
    try {
      const [resEsp, resArea] = await Promise.all([
        fetch("http://localhost:3001/especialidades"),
        fetch("http://localhost:3001/areasAtuacao")
      ]);
      if (resEsp.ok) especialidades = await resEsp.json();
      if (resArea.ok) areasAtuacao = await resArea.json();
      listasCarregadas = true;
    } catch (err) {
      console.error("Erro ao carregar listas:", err);
      listasCarregadas = false;
    }
  }
  carregarListas();

  // ===== CARREGAR DADOS DO PROFISSIONAL =====
  async function carregarDadosPerfil() {
    const profissional = JSON.parse(localStorage.getItem("profissional"));
    if (!profissional) {
      console.warn("Nenhum profissional logado encontrado no localStorage.");
      if (profileImage) profileImage.src = "img/perfil siru.jpg";
      return;
    }

    if (nomeCompleto) nomeCompleto.textContent = profissional.nome_profissional || "Seu Nome";
    if (nomeUsuarioHeader) nomeUsuarioHeader.textContent = profissional.nome_profissional || "";
    if (inputNome) inputNome.value = profissional.nome_profissional || "";
    if (inputEmail) inputEmail.value = profissional.email_profissional || "";
    if (inputSobre) inputSobre.value = profissional.sobre_mim || "";

    if (membroDesde && profissional.membroDesde) {
      const data = new Date(profissional.membroDesde);
      membroDesde.textContent = `Membro desde ${data.toLocaleDateString("pt-BR")}`;
    }

    if (profileImage) {
      profileImage.src = profissional.avatar
        ? (profissional.avatar.startsWith("http")
          ? profissional.avatar
          : "http://localhost:3001" + profissional.avatar)
        : "img/perfil siru.jpg";
    }

    // Buscar nomes reais da especialidade e área de atuação usando os IDs para preencher os inputs
    if (profissional.ESPECIALIDADE_especialidade_PK && inputEspecialidade) {
      try {
        const res = await fetch(`http://localhost:3001/especialidades/${profissional.ESPECIALIDADE_especialidade_PK}`);
        const data = await res.json();
        inputEspecialidade.value = data.especialidade || "";
      } catch (err) {
        console.error("Erro ao carregar especialidade:", err);
        inputEspecialidade.value = "";
      }
    }

    if (profissional.AREA_ATUACAO_areaAtuacao_PK && inputAreaAtuacao) {
      try {
        const res = await fetch(`http://localhost:3001/areasAtuacao/${profissional.AREA_ATUACAO_areaAtuacao_PK}`);
        const data = await res.json();
        inputAreaAtuacao.value = data.areaAtuacao || "";
      } catch (err) {
        console.error("Erro ao carregar área de atuação:", err);
        inputAreaAtuacao.value = "";
      }
    }
  }

  carregarDadosPerfil();

  
  // ===== ATUALIZAR DADOS DO PERFIL (NOME, SOBRE MIM) =====
if (formPerfil) {
  formPerfil.addEventListener("submit", async (e) => {
    e.preventDefault();

    if (!listasCarregadas) {
      return alert("As listas de especialidades e áreas ainda estão carregando. Por favor, aguarde e tente novamente.");
    }

    const profissional = JSON.parse(localStorage.getItem("profissional"));
    if (!profissional) return alert("Nenhum profissional logado.");

    const dadosAtualizados = {
      nome_profissional: inputNome.value,
      sobre_mim: inputSobre?.value || "",
    };

    // Verifique se o nome ou sobre mim foi alterado antes de atualizar
    const camposAlterados = Object.keys(dadosAtualizados).filter(key => dadosAtualizados[key] !== profissional[key]);
    if (camposAlterados.length === 0) {
      return alert("Nenhuma alteração foi feita.");
    }

    // Validar especialidade e área de atuação
    const especialidadeDigitada = normalizar(inputEspecialidade.value);
    const areaDigitada = normalizar(inputAreaAtuacao.value);
    const especialidadeEncontrada = especialidades.find(e => normalizar(e.especialidade) === especialidadeDigitada);
    const areaEncontrada = areasAtuacao.find(a => normalizar(a.areaAtuacao) === areaDigitada);

    if (especialidadeEncontrada) {
      dadosAtualizados.ESPECIALIDADE_especialidade_PK = especialidadeEncontrada.especialidade_PK;
    } else if (inputEspecialidade.value) {
      // Se a especialidade foi preenchida mas não foi encontrada na lista, podemos adicionar um valor padrão (ou deixar de enviar a especialidade)
      // Nesse caso, a especialidade não será enviada como NULL, mas o campo será omitido.
      console.warn("Especialidade digitada não encontrada. Não será enviada.");
    }

    if (areaEncontrada) {
      dadosAtualizados.AREA_ATUACAO_areaAtuacao_PK = areaEncontrada.areaAtuacao_PK;
    } else if (inputAreaAtuacao.value) {
      // Caso a área de atuação tenha sido digitada e não encontrada, podemos adicionar um valor padrão ou ignorar.
      console.warn("Área de atuação digitada não encontrada. Não será enviada.");
    }

    // Se nem especialidade nem área de atuação foram encontradas e preenchidas, não envie esses campos.
    if (!dadosAtualizados.ESPECIALIDADE_especialidade_PK && !dadosAtualizados.AREA_ATUACAO_areaAtuacao_PK) {
      console.warn("Nenhuma especialidade ou área de atuação válida foi selecionada. Não será enviado.");
    }

    try {
      const id = profissional.idProfissional || profissional.id_profissional;
      if (id) {
        console.log("Enviando atualização:", dadosAtualizados);

        const res = await fetch(`http://localhost:3001/profissionais/${id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(dadosAtualizados)
        });

        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.message || "Erro ao atualizar perfil");
        }

        if (data.profissional) {
          localStorage.setItem("profissional", JSON.stringify(data.profissional));
          Object.assign(profissional, data.profissional);
          alert("Alterações salvas com sucesso!");
        } else {
          alert("Erro ao atualizar perfil: resposta inválida.");
        }
      }
    } catch (err) {
      console.error(err);
      alert(`Erro ao salvar alterações: ${err.message}`);
    }
  });
}

  // ===== EXCLUIR CONTA =====
  window.excluirConta = async () => {
    const profissional = JSON.parse(localStorage.getItem("profissional"));
    if (!profissional) return alert("Nenhum profissional logado.");
    if (!confirm("⚠️ Tem certeza que deseja excluir sua conta permanentemente?")) return;

    try {
      const id = profissional.idProfissional || profissional.id_profissional;
      if (!id) return alert("Não foi possível identificar o ID do profissional.");

      const response = await fetch(`http://localhost:3001/profissionais/${id}`, { method: "DELETE" });
      const data = await response.json();

      if (response.ok) {
        alert(data.message || "Conta excluída com sucesso!");
        localStorage.removeItem("profissional");
        window.location.href = "index.html";
      } else {
        alert(data.message || "Erro ao excluir conta.");
      }
    } catch (err) {
      console.error(err);
      alert("❌ Falha na exclusão. Tente novamente mais tarde.");
    }
  };

});
