document.addEventListener("DOMContentLoaded", () => {
  const chk = document.getElementById("checkbox");
  const nomeCompleto = document.getElementById("nomeCompleto");
  const nomeUsuarioHeader = document.getElementById("nome-usuario");
  const profileImage = document.getElementById("profileImage");
  const inputNome = document.getElementById("inputNome");
  const inputEmail = document.getElementById("inputEmail");
  const inputSobre = document.getElementById("inputSobreMim");
  const inputEspecialidade = document.getElementById("inputEspecialidade");
  const inputAreaAtuacao = document.getElementById("inputAreaAtuacao");
  const formPerfil = document.getElementById("formPerfil");
  const membroDesde = document.getElementById("membroDesde");

  const tabs = document.querySelectorAll(".tab-btn");
  const tabContents = document.querySelectorAll(".tab-content");

  // ===== FUNÇÃO PARA NORMALIZAR TEXTO =====
  function normalizar(texto) {
    return texto
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim()
      .toLowerCase();
  }

  // ===== MODO ESCURO =====
  if (chk) {
    if (localStorage.getItem("modo") === "dark") {
      document.body.classList.add("dark");
      chk.checked = true;
    }
    chk.addEventListener("change", () => {
      document.body.classList.toggle("dark");
      localStorage.setItem(
        "modo",
        document.body.classList.contains("dark") ? "dark" : "light"
      );
    });
  }

  // ===== ABAS =====
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      const target = tab.getAttribute("data-tab");
      tabContents.forEach(tc => {
        tc.classList.remove("active");
        if (tc.id === target) tc.classList.add("active");
      });
    });
  });

  // ==========================================
  // ===== UPLOAD DE FOTO DO PROFISSIONAL =====
  // ==========================================
  const uploadInput = document.getElementById("uploadInput");

  if (uploadInput) {
    uploadInput.addEventListener("change", async () => {
      const profissional = JSON.parse(localStorage.getItem("profissional"));
      if (!profissional) return alert("Nenhum profissional logado.");

      if (uploadInput.files.length === 0) return;

      const file = uploadInput.files[0];

      // preview instantâneo
      profileImage.src = URL.createObjectURL(file);

      const formData = new FormData();
      formData.append("avatar", file);
      formData.append(
        "id_profissional",
        profissional.id_profissional || profissional.idProfissional
      );

      try {
        const res = await fetch("http://localhost:3001/profissionais/avatar", {
          method: "POST",
          body: formData,
        });

        const data = await res.json();

        if (!res.ok) {
          alert(data.message || "Erro ao enviar imagem.");
          return;
        }

        // Backend retorna: { message: "...", url: "http://localhost:3001/uploads/img.png" }

        // 🔥 Corrigindo caminhos:
        let url = data.url.replace("http://localhost:3001", "");
        if (!url.startsWith("/")) url = "/" + url;

        profileImage.src = "http://localhost:3001" + url;

        // salva no localStorage com caminho relativo consistente
        profissional.avatar = url;
        localStorage.setItem("profissional", JSON.stringify(profissional));

        alert("Foto atualizada com sucesso!");

      } catch (err) {
        console.error(err);
        alert("Erro ao enviar imagem.");
      }
    });
  }

  // ========================================================
  // ===== CARREGAR LISTAS DE ESPECIALIDADES E ÁREAS ========
  // ========================================================
  let especialidades = [];
  let areasAtuacao = [];
  let listasCarregadas = false;

  async function carregarListas() {
    try {
      const [resEsp, resArea] = await Promise.all([
        fetch("http://localhost:3001/especialidades"),
        fetch("http://localhost:3001/areasAtuacao"),
      ]);
      if (resEsp.ok) especialidades = await resEsp.json();
      if (resArea.ok) areasAtuacao = await resArea.json();
      listasCarregadas = true;
    } catch (err) {
      console.error("Erro ao carregar listas:", err);
    }
  }
  carregarListas();

  // ============================================
  // ===== CARREGAR DADOS DO PROFISSIONAL =======
  // ============================================
  async function carregarDadosPerfil() {
    const profissional = JSON.parse(localStorage.getItem("profissional"));
    if (!profissional) {
      profileImage.src = "img/perfil siru.jpg";
      return;
    }

    nomeCompleto.textContent = profissional.nome_profissional;
    nomeUsuarioHeader.textContent = profissional.nome_profissional;
    inputNome.value = profissional.nome_profissional;
    inputEmail.value = profissional.email_profissional; // email apenas exibição
    inputSobre.value = profissional.sobre_mim || "";

    if (membroDesde && profissional.membroDesde) {
      membroDesde.textContent =
        "Membro desde " +
        new Date(profissional.membroDesde).toLocaleDateString("pt-BR");
    }

    // FOTO DE PERFIL CORRIGIDA
    if (profissional.avatar) {
      profileImage.src = profissional.avatar.startsWith("http")
        ? profissional.avatar
        : "http://localhost:3001" + profissional.avatar;
    } else {
      profileImage.src = "img/perfil siru.jpg";
    }

    // ESPECIALIDADE
    if (profissional.ESPECIALIDADE_especialidade_PK) {
      try {
        const res = await fetch(
          `http://localhost:3001/especialidades/${profissional.ESPECIALIDADE_especialidade_PK}`
        );
        const data = await res.json();
        inputEspecialidade.value = data.especialidade || "";
      } catch {
        inputEspecialidade.value = "";
      }
    }

    // ÁREA DE ATUAÇÃO
    if (profissional.AREA_ATUACAO_areaAtuacao_PK) {
      try {
        const res = await fetch(
          `http://localhost:3001/areasAtuacao/${profissional.AREA_ATUACAO_areaAtuacao_PK}`
        );
        const data = await res.json();
        inputAreaAtuacao.value = data.areaAtuacao || "";
      } catch {
        inputAreaAtuacao.value = "";
      }
    }
  }
  carregarDadosPerfil();

  // ===============================================
  // ===== ATUALIZAR DADOS DO PERFIL (SEM EMAIL) ====
  // ===============================================
  if (formPerfil) {
    formPerfil.addEventListener("submit", async (e) => {
      e.preventDefault();

      if (!listasCarregadas)
        return alert("As listas ainda estão carregando.");

      const profissional = JSON.parse(localStorage.getItem("profissional"));
      if (!profissional) return alert("Nenhum profissional logado.");

      const dadosAtualizados = {};

      // nome e sobre mim
      if (inputNome.value !== profissional.nome_profissional)
        dadosAtualizados.nome_profissional = inputNome.value;

      if ((inputSobre.value || "") !== (profissional.sobre_mim || ""))
        dadosAtualizados.sobre_mim = inputSobre.value;

      // especialidade
      if (inputEspecialidade.value) {
        const espNorm = normalizar(inputEspecialidade.value);
        const espEncontrada = especialidades.find(
          (e) => normalizar(e.especialidade) === espNorm
        );

        dadosAtualizados.ESPECIALIDADE_especialidade_PK =
          espEncontrada?.especialidade_PK || null;
        if (!espEncontrada)
          dadosAtualizados.novaEspecialidade = inputEspecialidade.value;
      }

      // área de atuação
      if (inputAreaAtuacao.value) {
        const areaNorm = normalizar(inputAreaAtuacao.value);
        const areaEncontrada = areasAtuacao.find(
          (a) => normalizar(a.areaAtuacao) === areaNorm
        );

        dadosAtualizados.AREA_ATUACAO_areaAtuacao_PK =
          areaEncontrada?.areaAtuacao_PK || null;
        if (!areaEncontrada)
          dadosAtualizados.novaAreaAtuacao = inputAreaAtuacao.value;
      }

      // evitar PUT vazio
      if (Object.keys(dadosAtualizados).length === 0)
        return alert("Nenhuma alteração feita.");

      try {
        const id =
          profissional.idProfissional || profissional.id_profissional;

        const res = await fetch(
          `http://localhost:3001/profissionais/${id}`,
          {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(dadosAtualizados),
          }
        );

        const data = await res.json();

        if (!res.ok) throw new Error(data.message);

        if (data.profissional) {
          // atualizar localStorage
          localStorage.setItem(
            "profissional",
            JSON.stringify(data.profissional)
          );
          alert("Alterações salvas com sucesso!");
          carregarDadosPerfil();
        }

      } catch (err) {
        alert("Erro ao salvar alterações: " + err.message);
      }
    });
  }

  // ===============================================
  // ===== ALTERAR SENHA ============================
  // ===============================================
  const formSenha = document.getElementById("formSenha");
  if (formSenha) {
    formSenha.addEventListener("submit", async (e) => {
      e.preventDefault();

      const senhaAtual = document.getElementById("senhaAtual").value;
      const novaSenha = document.getElementById("novaSenha").value;
      const confirmaSenha =
        document.getElementById("confirmaNovaSenha").value;

      if (novaSenha !== confirmaSenha)
        return alert("As senhas não coincidem!");

      const profissional = JSON.parse(localStorage.getItem("profissional"));
      if (!profissional) return alert("Nenhum profissional logado.");

      try {
        const id =
          profissional.idProfissional || profissional.id_profissional;

        const res = await fetch(
          `http://localhost:3001/profissionais/${id}/alterar-senha`,
          {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ senhaAtual, novaSenha }),
          }
        );

        const data = await res.json();
        alert(data.message);

        if (res.ok) formSenha.reset();

      } catch {
        alert("Erro ao alterar senha.");
      }
    });
  }

  // ===============================================
  // ===== EXCLUIR CONTA ===========================
  // ===============================================
  window.excluirConta = async () => {
    const profissional = JSON.parse(localStorage.getItem("profissional"));
    if (!profissional) return alert("Nenhum profissional logado.");

    if (!confirm("Deseja excluir sua conta permanentemente?")) return;

    try {
      const id =
        profissional.idProfissional || profissional.id_profissional;

      const res = await fetch(
        `http://localhost:3001/profissionais/${id}`,
        { method: "DELETE" }
      );

      const data = await res.json();

      alert(data.message);

      if (res.ok) {
        localStorage.removeItem("profissional");
        window.location.href = "index.html";
      }
    } catch {
      alert("Erro ao excluir conta.");
    }
  };
});
