const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());

// SERVIR HTML, CSS, JS, IMAGENS
const frontendPath = path.join(__dirname, "frontend");
app.use(express.static(frontendPath));

// Conexão com MySQL (sua configuração)
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "MENTALLY"
});

db.connect(err => {
  if (err) return console.error("Erro ao conectar MySQL:", err);
  console.log("✅ Conectado ao MySQL");
});

// Rotas da API
app.get("/usuarios", (req, res) => {
  db.query(
    "SELECT CPF, nome_usuario, email_usuario, telefone, plano_tratamento FROM USUARIO",
    (err, results) => {
      if (err) return res.status(500).json(err);
      res.json(results);
    }
  );
});

app.post("/usuarios", (req, res) => {
  const { nome_usuario, email_usuario, senha_usuario } = req.body;
  if (!nome_usuario || !email_usuario || !senha_usuario)
    return res.status(400).json({ message: "Preencha todos os campos." });

  const sql = "INSERT INTO USUARIO (nome_usuario, email_usuario, senha_usuario) VALUES (?, ?, SHA2(?,256))";
  db.query(sql, [nome_usuario, email_usuario, senha_usuario], (err) => {
    if (err) return res.status(500).json({ message: "Erro ao cadastrar usuário." });
    res.json({ message: "Usuário cadastrado com sucesso!" });
  });
});

app.post("/login", (req, res) => {
  const { email_usuario, senha_usuario } = req.body;
  if (!email_usuario || !senha_usuario)
    return res.status(400).json({ message: "Preencha e-mail e senha." });

  const sql = "SELECT * FROM USUARIO WHERE email_usuario = ? AND senha_usuario = SHA2(?,256)";
  db.query(sql, [email_usuario, senha_usuario], (err, results) => {
    if (err) return res.status(500).json({ message: "Erro interno no servidor." });
    if (results.length === 0) return res.status(401).json({ message: "E-mail ou senha inválidos." });
    res.json({ message: "Login realizado com sucesso!", usuario: results[0] });
  });
});

// Iniciar servidor
const PORT = 3001;
app.listen(PORT, () => console.log(`🚀 Servidor rodando em http://localhost:${PORT}`));
