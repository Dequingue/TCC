const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());

// SERVIR FRONTEND
const frontendPath = path.join(__dirname, "../frontend");
app.use(express.static(frontendPath));

// Conexão com MySQL
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "MENTALLY"
});

db.connect(err => {
  if (err) return console.error("❌ Erro ao conectar MySQL:", err);
  console.log("✅ Conectado ao MySQL");
});

// Rotas da API
app.get("/usuarios", (req, res) => {
  db.query(
    "SELECT id_usuario, CPF, nome_usuario, email_usuario, telefone, plano_tratamento FROM USUARIO",
    (err, results) => {
      if (err) return res.status(500).json(err);
      res.json(results);
    }
  );
});

app.post("/usuarios", (req, res) => {
  const { nome_usuario, email_usuario, senha_usuario } = req.body;
  if (!nome_usuario || !email_usuario || !senha_usuario)
    return res.status(400).json({ message: "Preencha todos os campos." });

  const sql = "INSERT INTO USUARIO (nome_usuario, email_usuario, senha_usuario) VALUES (?, ?, SHA2(?,256))";
  db.query(sql, [nome_usuario, email_usuario, senha_usuario], (err) => {
    if (err) return res.status(500).json({ message: "Erro ao cadastrar usuário." });
    res.json({ message: "Usuário cadastrado com sucesso!" });
  });
});

app.post("/login", (req, res) => {
  const { email_usuario, senha_usuario } = req.body;
  if (!email_usuario || !senha_usuario)
    return res.status(400).json({ message: "Preencha e-mail e senha." });

  
  const sql = "SELECT * FROM USUARIO WHERE email_usuario = ? AND senha_usuario = SHA2(?,256)";
  db.query(sql, [email_usuario, senha_usuario], (err, results) => {
    if (err) return res.status(500).json({ message: "Erro interno no servidor." });
    if (results.length === 0) return res.status(401).json({ message: "E-mail ou senha inválidos." });
    res.json({ message: "Login realizado com sucesso!", usuario: results[0] });
  });
});

// NOVA ROTA PUT: Atualizar usuário pelo id_usuario
app.put("/usuarios/:id_usuario", (req, res) => {
  const { id_usuario } = req.params;
  const { nome_usuario, email_usuario, telefone } = req.body;

  if (!nome_usuario || !email_usuario) {
    return res.status(400).json({ message: "Nome e email são obrigatórios." });
  }

  const sql = "UPDATE USUARIO SET nome_usuario = ?, email_usuario = ?, telefone = ? WHERE id_usuario = ?";
  db.query(sql, [nome_usuario, email_usuario, telefone, id_usuario], (err, result) => {
    if (err) return res.status(500).json({ message: "Erro ao atualizar usuário.", error: err });
    if (result.affectedRows === 0) return res.status(404).json({ message: "Usuário não encontrado." });
    res.json({ message: "Perfil atualizado com sucesso!" });
  });
});
app.post("/agendamentos", (req, res) => {
  console.log("📥 Dados recebidos para agendamento:", req.body);
const {
  PROFISSIONAIS_idProfissional,
  USUARIO_CPF,
  data_consulta,
  hora_consulta,
  relato_consulta = null,
  nota_consulta = null,
  observacao_consulta = null
} = req.body;

  const sql = `
    INSERT INTO CONSULTA (
      PROFISSIONAIS_idProfissional,
      USUARIO_CPF,
      data_consulta,
      hora_consulta,
      relato_consulta,
      nota_consulta,
      observacao_consulta
    ) VALUES (?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(sql, [
    PROFISSIONAIS_idProfissional,
    USUARIO_CPF,
    data_consulta,
    hora_consulta,
    relato_consulta,
    nota_consulta,
    observacao_consulta
  ], (err, result) => {
    if (err) {
      console.error("Erro ao agendar:", err);
      return res.status(500).json({ message: "Erro ao agendar." });
    }
    res.json({ message: "Agendamento realizado com sucesso!" });
  });
  
});

// Fallback para SPA ou página inicial
app.get("/", (req, res) => {
  res.sendFile(path.join(frontendPath, "index.html"));
});

// Iniciar servidor
const PORT = 3001;
app.listen(PORT, () => console.log(`🚀 Servidor rodando em http://localhost:${PORT}`));
